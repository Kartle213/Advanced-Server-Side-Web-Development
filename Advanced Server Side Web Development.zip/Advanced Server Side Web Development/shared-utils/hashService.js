const crypto = require('crypto')

const hash = async (stringToHash) =>{


    return await crypto.createHash('sha256').update(stringToHash).digest('hex')

}

module.exports = hash