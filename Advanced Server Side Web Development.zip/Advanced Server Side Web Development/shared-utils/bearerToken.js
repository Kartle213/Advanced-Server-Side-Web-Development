const { verify } = require('crypto')
const jwt = require('jsonwebtoken')

const JWT_SECRET = process.env.JWT_SECRET
const REFRESH_SECRET = process.env.REFRESH_SECRET
const JWT_EXPIRY = '10m'
const REFRESH_EXPIRY = '7d'

const generateToken = async (user)=>{

    console.log("Generating token for user:", user) // Log the user object to see what is being passed in

    const jwtPayload = {
        userID:user.id || user.userID,
        email: user.email,
        userType: user.userType
    }

    const accessToken = await jwt.sign(jwtPayload,JWT_SECRET,{expiresIn:JWT_EXPIRY})

    const refreshPayload = {
        userID : user.id || user.userID,
        email: user.email,
        userType: user.userType
    }

    const refreshToken = await jwt.sign(refreshPayload,REFRESH_SECRET,{expiresIn:REFRESH_EXPIRY})

    return {
        accessToken:accessToken,
        refreshToken:refreshToken
    }
}

const verifyAccessToken = async(token) =>{
    try{
        return jwt.verify(token,JWT_SECRET)
    }catch(ex){
        throw ex
    }
}

const verifyRefreshToken = async(token) =>{
    try{
        return jwt.verify(token,REFRESH_SECRET)
    }catch(ex){
        throw ex
    }
}

module.exports = {
    generateToken,
    verifyAccessToken,
    verifyRefreshToken
}