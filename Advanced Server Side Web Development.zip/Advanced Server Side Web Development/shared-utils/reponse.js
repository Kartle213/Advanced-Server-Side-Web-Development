const createResponse =  (success, data = null,serviceID = null,error = null ) =>{
    return {
        success,
        data,
        serviceID,
        error: error?.message || error
    }
}

module.exports = createResponse
