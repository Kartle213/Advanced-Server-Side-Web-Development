document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-login').addEventListener('click', async (e) =>{
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        

        if (!email || !password) {
            alert('Please enter both email and password.');
            return;
        }

        if (email.trim() === '' || password.trim() === '') {
            alert('Please enter both email and password.');
            return;
        }

        

        const userData = {
            email: email,
            password: password
        }

        
        const response = await fetch('/alumni/retrieveByEmail', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        
        console.log(response)

        if (response.redirected) {
        
            alert('Login successful!');
            window.location.href = response.url;
        } else {
            alert('Login failed. Please check your email and password.');
        }
    })
})