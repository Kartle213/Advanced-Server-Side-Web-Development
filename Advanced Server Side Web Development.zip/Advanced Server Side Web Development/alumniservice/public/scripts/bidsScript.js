document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("btnBid").addEventListener("click", async () => {

        const bidAmount = document.getElementById("bidAmount").value;
        
        if(parseFloat(bidAmount) < 0 || isNaN(bidAmount) || bidAmount.trim() === ""){
            alert("Please enter a valid bid amount greater than 0.");
            return;
        }

        const biddata = {
            bid:bidAmount
        }

        const reponse = await fetch("/bid/makebid", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(biddata)
        });

        const result = await reponse.json();

        console.log(result)

        if(reponse.ok){
            if (!result.success){
                alert(result.error)
                return
            }
            alert("Bid placed successfully!");
            document.getElementById("bidAmount").value = "";
            ReloadBids()
            displayCurrentBid()
        } else {
            alert("Failed to place bid. Please try again.");
        }
    });

    document.getElementById("btnWithdraw").addEventListener("click" , async ()=>{

        const response = await fetch("/bid/withdrawLastBid") 

        const result = await response.json()
        if (response.ok){
            if (!result.success){
                alert(result.error)
                return
            }
            alert("Bid withdrawn")
            displayCurrentBid()
        }
        else{
            alert("Unable to withdraw bid")
        }
    })

    async function loadMonthlyLimit() {
        try {
            const response = await fetch('/alumni/monthly-limits')
            const result = await response.json()

            

            if (result.success) {
                const used = result.data.appearanceCount
                const attendedEvent = result.data.attendedEvent
                const total = attendedEvent ? 4 : 3

                document.getElementById('limitUsed').textContent = used
                document.getElementById('limitTotal').textContent = total
                document.getElementById('limitBar').style.width = `${(used / total) * 100}%`
                document.getElementById('limitNote').textContent = `${total - used} slots remaining this month`
            }
        } catch (error) {
            console.error('Failed to load monthly limit:')
        }
    }

    function startCountdown() {
        const timerElement = document.getElementById('countdown')

        function update() {
            const now = new Date()
            const cutoff = new Date()
            cutoff.setHours(18, 0, 0, 0)

            // If past 6 PM, count down to tomorrow's 6 PM
            if (now >= cutoff) {
                cutoff.setDate(cutoff.getDate() + 1)
            }

            const diff = cutoff - now
            const hours = Math.floor(diff / (1000 * 60 * 60))
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
            const seconds = Math.floor((diff % (1000 * 60)) / 1000)

            const pad = (n) => String(n).padStart(2, '0')
            timerElement.textContent = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
        }

        update()
        setInterval(update, 1000)
    }

    async function ReloadBids(){
        // TODO: Implement AJAX call to fetch latest bids and update the bid list on the page
        try{

            response = await fetch('/bid/bidStatus')
            const result = await response.json()

            console.log(result.success)

            if (result.success) {
                const statusEl = document.getElementById('bidStatus')
                const textEl = document.getElementById('bidStatusText')

                statusEl.classList.remove('winning', 'losing', 'tied')
                statusEl.classList.add(result.data.status)
                textEl.textContent = result.data.message
        }

        }catch(error){
            console.error('Failed to reload bids')
        }
    }



    async function displayCurrentBid() {
    try {
        const response = await fetch('/bid/allBids')
        const result = await response.json()

        let bid = 0
        if (response.ok && result.success && result.data) {
            bid = result.data.totalAmount
        }

     

        const bidResult = document.getElementById("bidResult")
        bidResult.textContent = "Current Bid: £" + bid
    } catch (error) {
        console.error('Failed to display current bid')
    }
}

    displayCurrentBid()
    ReloadBids()
    setInterval(ReloadBids, 10000)
    startCountdown()
    loadMonthlyLimit()

});