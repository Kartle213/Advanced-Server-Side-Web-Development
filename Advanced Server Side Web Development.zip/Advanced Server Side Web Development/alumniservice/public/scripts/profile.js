document.addEventListener('DOMContentLoaded', () => {

   

    document.getElementById('save-profile').addEventListener('click', async (e) => {

        const biography = null
        const linkedinUrl = null

    }) 

    document.getElementById('btnAddDegree').addEventListener('click', async (e) => {
        const tableName = 'degrees'

        console.log("click")

        const degreeType = document.getElementById('edu-degreeType').value;
        const degreeName = document.getElementById('edu-field').value;
        const institution = document.getElementById('edu-institution').value;
        const startYear = document.getElementById('edu-startYear').value;
        const graduationYear = document.getElementById('edu-endYear').value;
        const grade = document.getElementById('edu-grade').value;
        const universityUrl = document.getElementById('edu-url').value;

        if (!degreeName || !institution || !graduationYear ||!grade || !degreeType||!startYear) {
            alert('Please fill in all fields for the degree.');
            return;
        }

        if (degreeName.trim() === "" || institution.trim() === "" || graduationYear.trim() === "" ||grade.trim() === "" || degreeType.trim() === "") {
            alert('Please fill in all fields for the degree.');
            return;
        }

        const Data = {
            degreeName,
            degreeType,
            institution,
            graduationYear,
            startYear,
            grade,
            universityUrl
            
            
        };

        const response = await sendToBackEnd(tableName,Data)
        const result = await response.json()

          if (!result.success){
                alert(result.error || "Error when updating")
                return
            }

            alert("Successfully updated Degree")
        
    })

    document.getElementById('btnAddCertification').addEventListener('click', async (e) => {
        console.log("click")
        const data = {
            certName: document.getElementById('cert-name').value,
            org: document.getElementById('cert-org').value,
            courseUrl: document.getElementById('cert-url').value,
            completionDate: document.getElementById('cert-completionDate').value
        }
 
        if (!data.certName || !data.org || !data.completionDate) {
            alert('Please fill in all required certification fields.')
            return
        }

        if (data.certName.trim() === "" || data.org.trim() === ""){
             alert('Please fill in all required certification fields.')
            return
        }
 
        const response = await sendToBackEnd('certifications', data)
        const result = await response.json()

      
            console.log(result)
       
            if (!result.success){
                alert(result.error || "Error when updating")
                return
            }

            alert("Successfully updated Certification")

        

     
        
    })

    document.getElementById('btnAddLicence').addEventListener('click', async (e) => {
        const data = {
            licenceName: document.getElementById('lic-name').value,
            awardingBody: document.getElementById('lic-body').value,
            awardingBodyUrl: document.getElementById('lic-url').value,
            completionDate: document.getElementById('lic-completionDate').value
        }
 
        if (!data.licenceName || !data.awardingBody || !data.completionDate) {
            alert('Please fill in all required licence fields.')
            return
        }

        if(data.licenceName.trim() === "" || data.licenceName.trim() === ""){
            alert('Please fill in all required work experience fields.')
            return
        }
 
        const response = await sendToBackEnd('licences', data)
        const result = await response.json()

        console.log(result)

          if (!result.success){
                alert(result.error || "Error when updating")
                return
            }

            alert("Successfully updated Liscence")
    })
    
    document.getElementById('short-coursesbtn').addEventListener('click', async (e) => {
         const data = {
            courseName: document.getElementById('course-name').value,
            provider: document.getElementById('course-provider').value,
            courseUrl: document.getElementById('course-url').value,
            completionDate: document.getElementById('course-completionDate').value
        }
        
      

        if (!data.courseName || !data.provider || !data.completionDate) {
            alert('Please fill in all required course fields.')
            return
        }

        if(data.courseName.trim() === "" || data.provider.trim() === ""){
            alert('Please fill in all required work experience fields.')
            return
        }
 
       const response = await sendToBackEnd('short_courses', data)
       const result = await response.json()

     

         if (!result.success){
                alert(result.error || "Error when updating")
                return
            }

            alert("Successfully updated Course")
        
    })

    document.getElementById('btnAddWorkExperience').addEventListener('click', async (e) => {
        const current = document.getElementById('work-current').checked
        const data = {
            role: document.getElementById('work-title').value,
            companyName: document.getElementById('work-company').value,
            startDate: document.getElementById('work-startDate').value,
            endDate: current ? null : document.getElementById('work-endDate').value
        }
 
        if (!data.role || !data.companyName || !data.startDate) {
            alert('Please fill in all required work experience fields.')
            return
        }
        
        if(data.role.trim() === "" || data.companyName.trim() === ""){
            alert('Please fill in all required work experience fields.')
            return
        }

       const response = await sendToBackEnd('employment_history', data)
       const result = await response.json()

         if (!result.success){
                alert(result.error || "Error when updating")
                return
            }

            alert("Successfully updated Employment")
    })

 
    loadExistingEntries()

}



);

function addEntryToDisplay(type, title, detail, entryId, tableName) {
    const output = document.getElementById(type + '-output')

    const empty = output.querySelector('.output-empty')
    if (empty) empty.remove()

    const card = document.createElement('div')
    card.className = 'entry-card'
    card.dataset.id = entryId
    card.dataset.table = tableName
    card.innerHTML = `
        <div class="entry-actions">
            <button class="btn-entry-action" title="Remove">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                </svg>
            </button>
        </div>
        <div class="entry-title">${title}</div>
        <div class="entry-detail">${detail}</div>`

    card.querySelector('.btn-entry-action').addEventListener('click', () => removeEntry(card))
    output.appendChild(card)
}

async function removeEntry(card) {
    console.log("click")
    const entryId = card.dataset.id
    const tableName = card.dataset.table

    if (!confirm('Are you sure you want to delete this?')) return

    try {
        const response = await fetch('/alumni/deleteEntry', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ tableName, entryId })
        })

        const result = await response.json()
        console.log(result)

        if (response.ok && result.success) {
            const list = card.parentElement
            card.remove()

            if (list.children.length === 0) {
                const type = list.id.replace('-output', '')
                const labels = {
                    education: 'degrees',
                    certifications: 'certifications',
                    licences: 'licences',
                    courses: 'short courses',
                    work: 'work experience'
                }
                list.innerHTML = `<div class="output-empty">No ${labels[type] || type} added yet</div>`
            }
        } else {
            alert('Failed to delete: ' + (result.error || 'Please try again'))
        }
    } catch (error) {
        alert('An error occurred while deleting.')
    }
}
async function loadExistingEntries() {
    try {
        const response = await fetch('/alumni/getProfile')
        const result = await response.json()

        console.log("here")

        if (!result.success || !result.data) return
  console.log("here 2 ")
        const data = result.data

        if (data.degrees && data.degrees.length > 0) {
            data.degrees.forEach(d => {
                addEntryToDisplay('education', d.degreeName, 
                    `${d.institution || ''} &middot; ${d.startYear || ''} &ndash; ${d.completionDate || ''}${d.grade ? '<br>' + d.grade : ''}${d.universityUrl ? '<br><a class="entry-link" href="' + d.universityUrl + '" target="_blank">View course page</a>' : ''}`,
                    d.id, 'degrees')
            })
        }

        if (data.certifications && data.certifications.length > 0) {
            data.certifications.forEach(c => {
                addEntryToDisplay('certifications', c.certName, 
                    `${c.org || ''} &middot; Completed: ${c.completionDate || ''}${c.courseUrl ? '<br><a class="entry-link" href="' + c.courseUrl + '" target="_blank">View credential</a>' : ''}`,
                    c.id, 'certifications')
            })
        }

        if (data.licences && data.licences.length > 0) {
            data.licences.forEach(l => {
                addEntryToDisplay('licences', l.licenceName, 
                    `${l.awardingBody || ''} &middot; Obtained: ${l.completionDate || ''}${l.awardingBodyUrl ? '<br><a class="entry-link" href="' + l.awardingBodyUrl + '" target="_blank">View awarding body</a>' : ''}`,
                    l.id, 'licences')
            })
        }

        if (data.shortCourses && data.shortCourses.length > 0) {
            data.shortCourses.forEach(s => {
                addEntryToDisplay('courses', s.courseName, 
                    `${s.provider || ''} &middot; Completed: ${s.completionDate || ''}${s.courseUrl ? '<br><a class="entry-link" href="' + s.courseUrl + '" target="_blank">View course page</a>' : ''}`,
                    s.id, 'short_courses')
            })
        }

        if (data.employment && data.employment.length > 0) {
            data.employment.forEach(e => {
                addEntryToDisplay('work', e.role, 
                    `${e.companyName} &middot; ${e.startDate} &ndash; ${e.endDate || 'Present'}`,
                    e.id, 'employment_history')
            })
        }

    } catch (error) {
        console.error('Failed to load profile data:', error)
    }
}

async function sendToBackEnd(tablename,data){

    try{

        const payload = {
            tableName: tablename,
            data:data
        }
        const response = await fetch('/alumni/updateProfile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

    

        return response

        

    }catch(error){

        alert("An error occurred while saving your profile. Please try again.")
        
    }



}