require('dotenv').config()
const express = require('express')
const app = express()
const PORT = process.env.PORT


const alumnirouter = require('./routes/alumniroute')
const uiRouter = require('./routes/uiroute')
const bidRouter = require('./routes/bidroute')
const cookieparser = require('cookie-parser')
const swaggerUI = require('swagger-ui-express')
const swaggerJSdoc = require('./swagger')
const initCronJobs = require('./cronjobs/jobs')
const rateLimit = require('express-rate-limit')

const limiter = rateLimit({
    windowMs: 15*60*1000,
    max: 200,
    //message: "Too many requests from this IP, please try again after 15 minutes"
})

app.use(limiter) 
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerJSdoc))
app.use(express.json())
app.use(express.static('public'))
app.use(cookieparser())
app.use('/ui' , uiRouter)
app.use('/bid' , bidRouter)
app.use('/alumni' , alumnirouter)

app.listen(PORT, (err) =>{
    initCronJobs()
    if (err){
        console.error(err)
        
    }else{
        console.log(`Alumni Service Listening on Port ${PORT}`)
    }
})