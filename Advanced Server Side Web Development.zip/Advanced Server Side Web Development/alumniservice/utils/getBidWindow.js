function getBidWindow() {
    const now = new Date()

    const cutoff = new Date(now)
    cutoff.setHours(18, 0, 0, 0)

    let start, end

    if (now >= cutoff) {
        start = formatLocal(cutoff)
        end = formatLocal(new Date(cutoff.getTime() + 24 * 60 * 60 * 1000))
    } else {
        start = formatLocal(new Date(cutoff.getTime() - 24 * 60 * 60 * 1000))
        end = formatLocal(cutoff)
    }

    return { start, end }
}

function formatLocal(date) {
    const y = date.getFullYear()
    const m = String(date.getMonth() + 1).padStart(2, '0')
    const d = String(date.getDate()).padStart(2, '0')
    const h = String(date.getHours()).padStart(2, '0')
    const min = String(date.getMinutes()).padStart(2, '0')
    const s = String(date.getSeconds()).padStart(2, '0')
    return `${y}-${m}-${d} ${h}:${min}:${s}`
}

module.exports = {getBidWindow,formatLocal}