const express = require('express')
const router = express.Router()
const alumniservice = require('../services/alumniservice')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')


router.post('/create' , async (req,res) =>{
    this.service = new alumniservice()
    const result = await this.service.create(req)
    res.json(result)
})

router.post('/updateProfile', jwtAuthMiddleware, async (req,res) =>{
    this.service = new alumniservice()
    const result = await this.service.updateProfile(req)
    console.log(result)
    res.json(result)
})
router.post('/retrieveByEmail' , async (req,res) =>{
    
    try{
    this.service = new alumniservice()
    const result = await this.service.retrieveByEmail(req)
    console.log("Result from retrieveByEmail route:", result) // Log the result to see what is being returned from the service  
    if (!result.success) {
       return res.status(401).json('failed to retrieve alumni by email')
    }

    res.cookie('access-token', result.data.accessToken ,{
        httpOnly:true,
        secure:true,
        sameSite:true,
        maxAge: 24 * 60 * 60 * 1000
    })

     res.cookie('refresh-token', result.data.refreshToken ,{
        httpOnly:true,
        secure:true,
        sameSite:true,
        maxAge: 7 *24 * 60 * 60 * 1000
    })

    res.redirect('/ui/dashboard')
    }catch(error){
        console.error('Error in /retrieveByEmail route:', error)
        res.status(500).json({ success: false, error: 'Internal server error' })
    }
})

router.get('/monthly-limits', jwtAuthMiddleware, async (req,res) =>{
    this.service = new alumniservice()
     
    const result = await this.service.getMonthlyLimits(req)
    
    res.json(result)
})

router.post('/refresh', async (req, res) => {
    const refreshToken = req.cookies?.['refresh-token']

    if (!refreshToken) {
        return res.status(401).json({ success: false, error: 'No refresh token' })
    }

    try {
        const decoded = await bearerToken.verifyRefreshToken(refreshToken)

        if (!decoded) {
            return res.status(401).json({ success: false, error: 'Invalid refresh token' })
        }

        const newTokens = await bearerToken.generateToken({
            userID: decoded.userID || decoded.id, 
            email: decoded.email,
            userType: decoded.userType
        })

        res.cookie('access-token', newTokens.accessToken, {
            httpOnly: true,
            secure: true,
            sameSite: true,
            maxAge: 15 * 60 * 1000
        })

        res.json({ success: true })
    } catch (error) {
        res.status(401).json({ success: false, error: 'Refresh token expired' })
    }
})

/**
 * @swagger
 * /alumni/alumni-of-the-day:
 *   get:
 *     summary: Get today's featured Alumni of the Day
 *     description: Returns the profile of the alumni who won today's bidding round. This is the public API endpoint for developers.
 *     tags: [Public API]
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: Today's featured alumnus
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     bidderID:
 *                       type: integer
 *                       example: 4
 *                     bidAmount:
 *                       type: number
 *                       example: 250.00
 *                     winDate:
 *                       type: string
 *                       example: "2026-04-02"
 *                     fn:
 *                       type: string
 *                       example: Sarah
 *                     sn:
 *                       type: string
 *                       example: Johnson
 *                     biography:
 *                       type: string
 *                       example: "Software Engineer with 10 years experience..."
 *                     linkedinUrl:
 *                       type: string
 *                       example: "https://linkedin.com/in/sarah-johnson"
 *                     profileImagePath:
 *                       type: string
 *                       example: "/uploads/profile-images/1774584099981-photo.jpg"
 *                 serviceID:
 *                   type: string
 *                   nullable: true
 *                 error:
 *                   type: string
 *                   nullable: true
 *       404:
 *         description: No alumni of the day selected yet
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 error:
 *                   type: string
 *                   example: "No alumni of the day"
 */
router.get('/alumni-of-the-day', async (req, res) => {
    this.service = new alumniservice()
    const result = await this.service.getAlumniOfTheDay()
    res.json(result)
})

router.get('/getProfile', jwtAuthMiddleware, async (req, res) => {
    this.service = new alumniservice()
    const result = await this.service.getProfile(req.user.userID)
    console.log("full profile: " , result)
    res.json(result)
})

router.post('/deleteEntry', jwtAuthMiddleware, async (req, res) => {
    console.log("got here")
    this.service = new alumniservice()
    const result = await this.service.deleteEntry(req)

    res.json(result)
})

module.exports = router