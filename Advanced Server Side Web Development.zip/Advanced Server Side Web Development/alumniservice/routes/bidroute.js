const express = require('express')
const router = express.Router()
const bidservice = require('../services/bidservice')
const jwtAuthmiddleware = require('../middleware/jwtAuthMiddleware')

router.post('/makebid' , jwtAuthmiddleware, async (req,res) =>{
    const service = new bidservice()
    const result = await service.createbid(req)
    if (!result.success) {
        return res.json(result)
    }

    res.json(result)
})

router.get('/bidStatus', jwtAuthmiddleware, async (req,res) =>{
    const service = new bidservice()
    const result = await service.getCurrentBidStatus(req.user.userID)
   
    if (!result.success) {
        
       return  res.json('failed to retrieve bid status')
    }
    res.json(result)
})

router.get('/bidsToday',jwtAuthmiddleware, async (req,res) =>{
    const service = new bidservice();
    const result = service.getAllBidsTodayByID(req.user.userID)

    if(!result.success){
        return res.json('failed to get bids')
    }
    res.json(result)

})

router.get('/allBids',jwtAuthmiddleware, async (req,res) =>{
    const service = new bidservice();
    const result = await service.getAllBidsTodayByID(req.user.userID)

    if (!result.success){
       return  res.json('failed to retrieve bid status')
    }

    res.json(result)
})

router.get('/withdrawLastBid' , jwtAuthmiddleware , async (req,res) =>{
    try {
        this.service = new bidservice()
        const result = await this.service.withdrawLastBid(req.user.userID)
        res.json(result)
    } catch (error) {
        console.error('Withdraw error:', error.message)
        res.status(500).json({ success: false, error: error.message })
    }
})

module.exports = router