const express = require('express')
const router = express.Router()
const path = require('path')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')

router.get('/', async (req, res) => {
    res.redirect('/ui/login')
})

router.get('/login' , async (req,res) =>{
 
    res.sendFile(path.join(__dirname,'..','public','login.html'))
})

router.get('/register' , async (req,res) =>{
    
    res.sendFile(path.join(__dirname,'..','public','register.html'))
})

router.get('/dashboard' , jwtAuthMiddleware, async (req,res) =>{
  
    res.sendFile(path.join(__dirname,'..','public','dashboard.html'))
})

router.get('/profile', jwtAuthMiddleware, async (req,res) =>{
  
      res.sendFile(path.join(__dirname,'..','public','profile.html'))
      
})

router.get('/mybids', jwtAuthMiddleware, async (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'mybids.html'))
})

router.get('/logout', async (req,res) =>{
    res.clearCookie('access-token')
    res.clearCookie('refresh-token')
    res.redirect('/ui/login')
})

module.exports = router