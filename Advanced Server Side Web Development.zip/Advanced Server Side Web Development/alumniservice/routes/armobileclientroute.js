const express = require('express')
const router = express.Router()
//const fullprofileservice = require('../services/bidservice')
const jwtAuthmiddleware = require('../middleware/jwtAuthMiddleware')

/**
 * @swagger
 * /fullprofile:
 *   get:
 *     summary: Retrieve the full profile of an alumni
 *     tags:
 *       - alumni
 *     description: Retrieve the full profile of an alumni using their ID.
 *     parameters:
 *       - in: query
 *         name: alumniId
 *         required: true
 *         schema:
 *           type: integer
 *         description: The ID of the alumni whose profile to retrieve
 *         example: 123
 *     responses:
 *       200:
 *         description: The full profile of the alumni
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 title:
 *                   type: string
 *                   example: "MSc Software Engineer"
 *                 institution:
 *                   type: string
 *                   example: "University of Eastminster"
 *                 graduationYear:
 *                   type: integer
 *                   example: 2020
 *                 grade:
 *                   type: string
 *                   example: "First Class"
 *                 isEndorsed:
 *                   type: boolean
 *                   example: true
 *       404:
 *         description: Alumni not found
 *       500:
 *         description: Internal server error
 */
router.get('/fullprofile', jwtAuthmiddleware, async (req, res) => {
    const { alumniId } = req.query

    this.service = new alumniservice()
    const userID = req.user.userID || alumniId
    const result = await this.service.getProfile(userID)

    if (!result.success){
        return res.json(result.error)
    }

    res.json(result)

    // your logic here
})

module.exports = router