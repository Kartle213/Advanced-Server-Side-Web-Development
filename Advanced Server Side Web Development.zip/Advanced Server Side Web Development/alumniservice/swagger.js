const swaggerJSdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Alumni Service API',
      version: '1.0.0',
      description: 'API documentation for the Alumni Service',
    },
    servers: [{url: 'http://localhost:3001'}],
  },
  apis: ['./routes/*.js'], 

};

module.exports = swaggerJSdoc(options);