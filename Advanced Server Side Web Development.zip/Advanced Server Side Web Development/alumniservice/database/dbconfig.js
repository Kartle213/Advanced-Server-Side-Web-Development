const db = require('sqlite3')
const connection = new db.Database('./auth.db' , (err) =>{
    if (err){
        console.error('Failed to connect to database!')
    }
    else{
        console.log('Alumni DB Connection Success')
    }
})

const dropTable = (tablename) =>{
    connection.run(`DROP TABLE ${tablename}`,(err) =>{
            if(err){
                console.error(`Error when dropping table ${tablename}`)
            }
            else{
                console.log(`Table ${tablename} Successfully Dropped`)}
            })
}

//User Table


const createAlumniProfilesTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS alumni_profiles(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId INTEGER NOT NULL UNIQUE,
            fn TEXT NOT NULL,
            sn TEXT NOT NULL,
            biography TEXT,
            linkedinUrl TEXT,
            profileImagePath TEXT,
            appearanceCount INTEGER DEFAULT 0,
            attendedEvent INTEGER DEFAULT 0,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
           )`
           
        , (err) => {
            if(err){
                console.error("Error creating Alumni Profiles table:");
            } else {
                console.log("Table Alumni Profiles Successfully created");
            }
        }); 
}

const createbidsTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS bids(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bidAmount REAL NOT NULL,
        bidderID INTEGER NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        withdrawnAt DATETIME DEFAULT NULL
    )`
        , (err) => {
            if(err){
                console.error("Error creating Bids table:");
            } else {
                console.log("Table Bids Successfully created");
            }
        }); 
}


const createCertificationsTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS certifications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumnusId INTEGER NOT NULL,
            certName TEXT NOT NULL,
            courseUrl TEXT,
            completionDate DATE,
            FOREIGN KEY (alumnusId) REFERENCES alumni_profiles(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err);
            } else {
                console.log("Table Certifications Successfully created");
            }
        });
}

const createLicencesTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS licences(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumnusId INTEGER NOT NULL,
            licenceName TEXT NOT NULL,
            awardingBodyUrl TEXT,
            completionDate DATE,
            FOREIGN KEY (alumnusId) REFERENCES alumni_profiles(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err);
            } else {
                console.log("Table Licences Successfully created");
            }
        });
}

const createShortCoursesTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS short_courses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumnusId INTEGER NOT NULL,
            courseName TEXT NOT NULL,
            courseUrl TEXT,
            completionDate DATE,
            FOREIGN KEY (alumnusId) REFERENCES alumni_profiles(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err);
            } else {
                console.log("Table Short Courses Successfully created");
            }
        });
}


const createEmploymentHistoryTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS employment_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumnusId INTEGER NOT NULL,
            companyName TEXT NOT NULL,
            role TEXT NOT NULL,
            startDate DATE NOT NULL,
            endDate DATE,
            FOREIGN KEY (alumnusId) REFERENCES alumni_profiles(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err);
            } else {
                console.log("Table Employment History Successfully created");
            }
        });
}

const createDegreesTable = () => {
    connection.run(`
        CREATE TABLE IF NOT EXISTS degrees(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumnusId INTEGER NOT NULL,
            degreeName TEXT NOT NULL,
            grade TEXT NOT NULL,
            universityUrl TEXT,
            startYear DATE NOT NULL,
            completionDate DATE NOT NULL,
            FOREIGN KEY (alumnusId) REFERENCES alumni_profiles(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err);
            } else {
                console.log("Table Degrees Successfully created");
            }
        });
}

createbidsTable();
createAlumniProfilesTable();
createCertificationsTable(); //
createLicencesTable(); //
createDegreesTable(); //
createShortCoursesTable(); //
createEmploymentHistoryTable();//

//dropTable();


module.exports = connection