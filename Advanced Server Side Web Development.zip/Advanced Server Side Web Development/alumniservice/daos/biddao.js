const connection = require('../database/dbconfig')
const createResponse = require('../../shared-utils/reponse')
const {getBidWindow} = require('../utils/getBidWindow')
const {formatLocal} = require('../utils/getBidWindow')
{}

class biddao{
    constructor(){



    }
    
    async create(bidderID, bidAmount){
        
        return new Promise((resolve) => {
        
       

        const query = `INSERT INTO bids (bidderID, bidAmount) VALUES (?, ?)`
        connection.run(query, [bidderID, bidAmount], function(err) {
        if (err) {
            
            return resolve(createResponse(false, null, null, "Failed to create bid"))
        }

        if (this.changes === 0) {
            return resolve(createResponse(false, null, null, "Failed to create bid"))
        }

        resolve(createResponse(true, { id: this.lastID }))
        })
    })
        
    }


    

    async selectTodaysBidWinner() {
        const { start, end } = getBidWindow()
        return new Promise((resolve) => {
            const query = `SELECT * FROM bids 
                WHERE createdAt > ? AND createdAt <= ? AND withdrawnAt IS NULL 
                ORDER BY bidAmount DESC LIMIT 1`
            connection.get(query, [start, end], function(err, row) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to select winner'))
                }
                if (!row) {
                    return resolve(createResponse(false, null, null, 'No bids for today'))
                }
                return resolve(createResponse(true, row))
            })
        })
    }

 async getTodaysBidByUserID(userID) {
    const { start, end } = getBidWindow()

    return new Promise((resolve) => {
        const query = `SELECT * FROM bids WHERE bidderID = ? AND createdAt > ? AND createdAt <= ?  AND withdrawnAt IS NULL ORDER BY bidAmount DESC LIMIT 1`
        connection.get(query, [userID, start, end], function(err, row) {
            if (err) {
                return resolve(createResponse(false, null, null, 'Failed to get bid'))
            }
            if (!row) {
                return resolve(createResponse(false, null, null, 'No bid found'))
            }
            return resolve(createResponse(true, row))
        })
    })
}

 async getAllBidsTodayByID(userID) {
    const { start, end } = getBidWindow()
    return new Promise((resolve) => {
        const query = `SELECT * FROM bids WHERE bidderID = ? AND createdAt > ? AND createdAt <= ?  AND withdrawnAt IS NULL ORDER BY bidAmount DESC`
        connection.all(query, [userID, start, end], function(err, rows) {
            if (err) {
                return resolve(createResponse(false, null, null, 'Failed to get bid'))
            }
            if (!rows || rows.length === 0) {
                return resolve(createResponse(false, null, null, 'No bid found'))
            }
            const totalSum = rows.reduce((acc, row) => acc + row.bidAmount, 0);
            return resolve(createResponse(true, {
                bids: rows,
                totalAmount: totalSum,
                count: rows.length
            }));
        })
    })
}

    async getTodaysHighestBid() {
        const { start, end } = getBidWindow()
        return new Promise((resolve) => {
            const query = `SELECT * FROM bids WHERE createdAt > ? AND createdAt <= ?  AND withdrawnAt IS NULL ORDER BY bidAmount DESC LIMIT 1`
            connection.get(query, [start, end], function(err, row) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to get highest bid'))
                }
                if (!row) {
                    return resolve(createResponse(false, null, null, 'No bids today'))
                }
                return resolve(createResponse(true, row))
            })
        })
    }

    async getAllBidsByID(userID) {
        return new Promise((resolve,reject)=>{
            const query = 'SELECT * FROM bids WHERE bidderID = ?'
            connection.get(query, [userID], function(err,row){
                if (err){
                    return resolve(createResponse(false,null,null,'Failed to get bids'))
                }
                if(!row){
                    return resolve(createResponse(false, null, null, 'No rows to display'))
                }

                return resolve(createResponse(false,row))

            })


        })
    }

    

    async withdrawLastBid(userID) {
        const { start, end } = getBidWindow()
        const nowFormatted = formatLocal(new Date());
        return new Promise((resolve) => {
            const query = `UPDATE bids SET withdrawnAt = ? 
                WHERE id = (
                    SELECT id FROM bids 
                    WHERE bidderID = ? AND createdAt > ? AND createdAt <= ? AND withdrawnAt IS NULL
                    ORDER BY createdAt DESC LIMIT 1
                ) AND NOT EXISTS (
                    SELECT 1 FROM bids 
                    WHERE bidderID = ? AND createdAt > ? AND createdAt <= ? AND withdrawnAt IS NOT NULL
                )`
            connection.run(query, [nowFormatted,userID, start, end, userID, start, end], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to withdraw bid'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'No active bid to withdraw or already used your withdraw for the day'))
                }
                return resolve(createResponse(true, null, null, 'Bid withdrawn successfully'))
            })
        })
}


}

module.exports = biddao
