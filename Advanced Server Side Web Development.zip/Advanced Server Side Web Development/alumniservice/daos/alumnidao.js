const connection = require('../database/dbconfig')
const createResponse = require('../../shared-utils/reponse')

class alumnidao{
    constructor(){


    }
    async create(req){

        return new Promise((resolve, reject) => {
            const query = 'INSERT INTO alumni_profiles(userId,fn,sn,linkedinUrl, createdAt,updatedAt) VALUES (?, ?, ?, ?, datetime("now"), datetime("now"))';
            connection.run(query, [req.body.user_id, req.body.fn, req.body.sn, req.body.linkedinUrl], function(err){
                if (err) {                    
                    
                    return resolve(createResponse(false,null,null,'Failed to create alumni', ));
                }

                if(this.changes === 0){
                    return resolve(createResponse(false,null,null,'Failed to create alumni', ));
                }
                return resolve(createResponse(true,null,null,'Alumni created successfully', ));

            })
        })

    }

    async deleteEntry(tableName, entryId, userId) {
    return new Promise((resolve) => {
        const query = `DELETE FROM ${tableName} WHERE id = ? AND alumnusId = (SELECT id FROM alumni_profiles WHERE userId = ?)`
        connection.run(query, [entryId, userId], function(err) {
            if (err) {
                return resolve(createResponse(false, null, null, 'Failed to delete'))
            }
            if (this.changes === 0) {
                return resolve(createResponse(false, null, null, 'Entry not found'))
            }
            return resolve(createResponse(true, null, null, 'Deleted successfully'))
        })
    })
}

    async getFullProfile(userId) {
    return new Promise((resolve) => {
        const profile = {}

        connection.get('SELECT * FROM alumni_profiles WHERE userId = ?', [userId], (err, row) => {
            if (err || !row) {
                return resolve(createResponse(false, null, null, 'Profile not found'))
            }

            profile.info = row

            connection.all('SELECT * FROM degrees WHERE alumnusId = ?', [row.id], (err, rows) => {
                profile.degrees = rows || []

                connection.all('SELECT * FROM certifications WHERE alumnusId = ?', [row.id], (err, rows) => {
                    profile.certifications = rows || []

                    connection.all('SELECT * FROM licences WHERE alumnusId = ?', [row.id], (err, rows) => {
                        profile.licences = rows || []

                        connection.all('SELECT * FROM short_courses WHERE alumnusId = ?', [row.id], (err, rows) => {
                            profile.shortCourses = rows || []

                            connection.all('SELECT * FROM employment_history WHERE alumnusId = ?', [row.id], (err, rows) => {
                                profile.employment = rows || []

                                return resolve(createResponse(true, profile))
                            })
                        })
                    })
                })
            })
        })
    })
}

    async retrieveByID(id){
        return new Promise((resolve, reject) => {
            const query = 'SELECT * FROM alumni_profiles WHERE userId = ?';
            connection.get(query, [id], function(err, row) {
                if (err) {
                    
                    return resolve(createResponse(false,null,null,'Failed to retrieve alumni', ));
                }
                if (!row) {
                    return resolve(createResponse(false,null,null,'Alumni not found', ));
                }
                return resolve(createResponse(true,row,null,'Alumni retrieved successfully', ));
            });
        });
    }

    async markWinner(bidderID) {
        return new Promise((resolve) => {
            const query = `UPDATE alumni_profiles 
                SET appearanceCount = appearanceCount + 1, updatedAt = datetime('now') 
                WHERE userId = ?`
            connection.run(query, [bidderID], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to mark winner'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'Profile not found'))
                }
                return resolve(createResponse(true, null, null, 'Winner marked successfully'))
            })
        })
    }

    async resetMonthlyAppearanceCount(){
        return new Promise((resolve, reject) => {
            const query = 'UPDATE alumni SET monthly_appearance_count = 0';
            connection.run(query, [],function (err) {
                if (err) {
                    return resolve(createResponse(500,null,null,'Error resetting monthly appearance count', ));
                } 

                if(this.changes === 0){
                    return resolve(createResponse(404,null,null,'No alumni found to reset monthly appearance count', ));
                }
                
                return resolve(createResponse(200,null,null,'Monthly appearance count reset successfully', ));
            })
    })

    }

    async insertDegree(userId, data) {
    return new Promise((resolve) => {
        const query = `INSERT INTO degrees (alumnusId, degreeName,grade, universityUrl,startYear,completionDate) 
                       VALUES (?, ?, ?,?, ?)`
        connection.run(query, [userId, data.degreeName, data.grade || null, data.universityUrl || null, data.startYear, data.graduationYear], function(err) {
            if (err) {
                return resolve(createResponse(false, null, null, 'Failed to add degree'))
            }
            if (this.changes === 0) {
                return resolve(createResponse(false, null, null, 'Failed to add degree'))
            }
            return resolve(createResponse(true, { id: this.lastID }))
        })
    })
    }   

    async insertCertification(userId, data) {
        return new Promise((resolve) => {
            const query = `INSERT INTO certifications (alumnusId, certName, courseUrl, completionDate) 
                        VALUES (?, ?, ?, ?)`
            connection.run(query, [userId, data.certName, data.courseUrl || null, data.completionDate], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to add certification'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'Failed to add certification'))
                }
                return resolve(createResponse(true, { id: this.lastID }))
            })
        })
    }

    async insertLicence(userId, data) {
        return new Promise((resolve) => {
            const query = `INSERT INTO licences (alumnusId, licenceName, awardingBodyUrl, completionDate) 
                        VALUES (?, ?, ?, ?)`
            connection.run(query, [userId, data.licenceName, data.awardingBodyUrl || null, data.completionDate], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to add licence'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'Failed to add licence'))
                }
                return resolve(createResponse(true, { id: this.lastID }))
            })
        })
    }

    async getMonthlyLimits(userId) {
        

    }


    

    async insertCourse(userId, data) {
        return new Promise((resolve) => {
            const query = `INSERT INTO short_courses (alumnusId, courseName, courseUrl, completionDate) 
                        VALUES (?, ?, ?, ?)`
            connection.run(query, [userId, data.courseName, data.courseUrl || null, data.completionDate], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to add course'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'Failed to add course'))
                }
                return resolve(createResponse(true, { id: this.lastID }))
            })
        })
    }

    async insertEmployment(userId, data) {
        return new Promise((resolve) => {
            const query = `INSERT INTO employment_history (alumnusId, companyName, role, startDate, endDate) 
                        VALUES (?, ?, ?, ?, ?)`
            connection.run(query, [userId, data.companyName, data.role, data.startDate, data.endDate || null], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to add employment'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'Failed to add employment'))
                }
                return resolve(createResponse(true, { id: this.lastID }))
            })
        })
    }
}

module.exports = alumnidao
