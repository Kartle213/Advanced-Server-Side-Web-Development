const { application, json } = require('express')
const hashService = require('../../shared-utils/hashService')
const createResponse = require('../../shared-utils/reponse')
const axios = require('axios')
require('dotenv').config()

const AUTH_SERVICE_API_KEY = process.env.AUTH_SERVICE_API_KEY
const BASE_URL = process.env.BASE_URL
const AUTH_SERVER_ID = process.env.AUTH_SERVER_ID

const authClient = axios.create({

    baseURL:BASE_URL,
    headers:{
        'x-api-key':AUTH_SERVICE_API_KEY,
        'Content-Type':'application/json'
    }
})

const verifyServiceID = async (serviceID) =>{
    const hashedServiceIdClone = await hashService(AUTH_SERVER_ID)

    if(!serviceID){
        return createResponse(false,null,null,"No service ID")
    }

    if (hashedServiceIdClone != serviceID){
        return createResponse(false,null,null,"Invalid service ID")
    }
    return createResponse(true,null)
}

const login = async (req , res) =>{ 
    console.log(BASE_URL)
    console.log("Login function called with request body:", req.body) // Log the request body to see what is being received
    const response = await authClient.post('/user/retrieveByEmail',
        {
            email:req.body.email,
            password:req.body.password

        })
    const isServiceValid = await verifyServiceID(response.data.serviceID)

    console.log("Service validation result:", isServiceValid)

    if (!isServiceValid.success){
        return createResponse(false,null,null,isServiceValid.error)
    }
    else{
        return createResponse(true,response.data.data)
    }
    
}

const register = async (req, res) => {
    try {
        const response = await authClient.post('/user/create', {
            fn: req.body.fn,
            sn: req.body.sn,
            email: req.body.email,
            password: req.body.password,
            linkedinURL: req.body.linkedinURL,
            userType: 'Alumni'
        })

        const isServiceValid = await verifyServiceID(response.data.serviceID)

        if (!isServiceValid.success) {
            return createResponse(false, null, null, isServiceValid.error)
        }

        return createResponse(true, response.data.data, response.data.serviceID, response.data.error)

    } catch (error) {

  

    return createResponse(false, null, null, 'Registration failed')
    
}
}

module.exports = {login , register}