const connection = require('../database/dbconfig')
const createResponse = require('../../shared-utils/reponse')
const biddao = require('../daos/biddao')
const alumniservice = require('../services/alumniservice')

class bidservice{
    constructor(){
        this.dao = new biddao()

    }
    async createbid(req){

      
        const bidamount = req.body.bid
        
        if(bidamount.trim() === "" || isNaN(bidamount) || parseFloat(bidamount) < 0){
            return createResponse(false,null,null,"Please enter a valid bid amount.")
        }

        console.log("Bidding")

        const service = new alumniservice()
        const responsetemp = await service.getMonthlyLimits(req)

        console.log("After monthly check")

        if(responsetemp.data.appearanceCount >= (responsetemp.data.attendedEvent ? 4:3)){
            return createResponse(false,null,null,"You have already have won the bid a maxium amount of times")
        }
        
        console.log("reaching here")

        const response = await this.dao.create(req.user.userID,bidamount)
        console.log("response: ",response)

        return response


    }

     async getAllBidsTodayByID(userID){
        return await this.dao.getAllBidsTodayByID(userID)
    }

    async getTodaysBidByID(userID){

        return await this.dao.getTodaysBidByUserID(userID)

    }

     async selectBidWinner(){
        const response = await this.dao.selectTodaysBidWinner()
        
        if (!response.success){
            return response
        }

        const result = await this.dao.mark

        return response

    }

    async getCurrentBidStatus(req){
       
        console.log("IN CURRENT BID STATUS")

        const response = await this.dao.getTodaysBidByUserID(req)

        console.log("responsefrom bidstauts: ",response)

        if (!response.success || !response.data) {
        return createResponse(true, { status: 'none', message: 'No active bid placed yet' })
        }

        const highestBid = await this.dao.getTodaysHighestBid()

        if ((!highestBid.success || !highestBid.data)  || (response.data.id == highestBid.data.id)) {
            return createResponse(true, { status: 'winning', message: 'You are currently winning' })
        }

        if (response.data.bidAmount > highestBid.data.bidAmount) {
            return createResponse(true, { status: 'winning', message: 'You are currently winning' })
        } else if (response.data.bidAmount === highestBid.data.bidAmount) {
            return createResponse(true, { status: 'tied', message: 'You are currently tied' })
        } else {
            return createResponse(true, { status: 'losing', message: 'You are currently losing' })
        }
           
    }

    async withdrawLastBid(userID){
        const response = await this.dao.withdrawLastBid(userID)
        console.log("response from the withdrawlast bid: ", response)
        return response
    }

    async retrieveByID(ID){}


}

module.exports = bidservice
