const { response } = require('express')
const alumnidao = require('../daos/alumnidao')
const {login , register} = require('./authServiceClient')
const createResponse = require('../../shared-utils/reponse')
const {generateToken} = require('../../shared-utils/bearerToken')
const hashService = require('../../shared-utils/hashService')

class alumniservice {
    constructor(){
        this.dao = new alumnidao()


    }
    async create(req){

        const fn = req.body.fn
        const sn = req.body.sn
        const password = req.body.password
        const email = req.body.email
        const linkedinUrl = req.body.linkedinUrl
        const confirmPassword = req.body.confirmPassword    
        //const serviceID = await hashService(process.env.serviceID)

        const emailDomain = email.split('@')[1]?.toLowerCase()
        const allowedDomains = ['westminster.ac.uk', 'eastminster.ac.uk']

        if (!emailDomain || !allowedDomains.includes(emailDomain)) {
            return createResponse(false, null, null, "Please use a valid university email address")
        }

         if (!fn || !sn || !password || !email){
            
            return createResponse(false,null,null,"Please fill in all fields")
        }

        if(fn.trim() === '' || sn.trim() === '' || email.trim() === '' || password.trim() === ''){
            return createResponse(false,null,null,"Please fill in all fields")
        }

        if (password.length < 8){
            return createResponse(false,null,null,"Password should be more then eight characters long")
        }


        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(password)) {
            return createResponse(false,null,null,"Password must contain at least one uppercase letter and one special character")
        }

        if (password !== confirmPassword){
            return createResponse(false,null,null,"Passwords do not match")
        }
        
        const reponse = await register(req)

        console.log("Register response2:", reponse)
        if (!reponse || !reponse.success){
            return createResponse(false,null,null,"Failed to register user")
        }

        
       
        req.body.user_id = reponse.data.id

        console.log("Request body before creating alumni profile:", response.data) // Log the request body to see what is being passed to the DAO
  
        
       

        const result = await this.dao.create(req)

        return createResponse(true,result.data,null,"User created successfully")

    }

    async retrieveByEmail(req){

        const email = req.body.email
        const password = req.body.password


        if (!email || !password){
            return createResponse(false,null,null,"Please fill in all fields")
        }
        
        if (email.trim() === '' || password.trim() === ''){
            return createResponse(false,null,null,"Invalid credentials")
        }

      

        const response = await login(req)

        if (!response.success || !response.data) {
            return createResponse(false, null, null, response.error || 'Login failed')
        }

        console.log("Login response:", response)

        const token = await generateToken(response.data)



        return createResponse(
            true,
            {
            user:response.data,
            accessToken: token.accessToken,
            refreshToken: token.refreshToken
        })

    }

    async updateProfile(req) {
    const { tableName, data } = req.body
    const userId = req.user.userID

  
    const profile = await this.dao.retrieveByID(userId)
    if (!profile.success || !profile.data) {
        return createResponse(false, null, null, 'Profile not found')
    }

    const profileId = profile.data.id

    switch (tableName) {
        case 'degrees':
            return this.validateAndInsertDegree(profileId, data)
        case 'certifications':
            return this.validateAndInsertCertification(profileId, data)
        case 'licences':
            return this.validateAndInsertLicence(profileId, data)
        case 'short_courses':
            return this.validateAndInsertCourse(profileId, data)
        case 'employment_history':
            return this.validateAndInsertEmployment(profileId, data)
        default:
            return createResponse(false, null, null, 'Invalid table name')
    }
}

    async markWinner(userID){
            return await this.dao.markWinner(userID)
    }

    async getAlumniOfTheDay(){
        return await this.dao.selectTodaysBidWinner()
    }

    async getMonthlyLimits(req){

        const reponse = await this.dao.retrieveByID(req.user.userID)
        if (!reponse.success || !reponse.data) {
            return createResponse(false, null, null, reponse.error || 'Failed to retrieve user data')
        }


        const apperanceData = {

            attendedEvent: reponse.data.attendedEvent,
            appearanceCount: reponse.data.appearanceCount

        }

   

        return createResponse(true, apperanceData, null, 'Monthly limits retrieved successfully')
    }

    async getProfile(userID){
        return await this.dao.getFullProfile(userID)
    }

   

    validateAndInsertDegree(userId, data) {
        if (!data.degreeName || !data.institution || !data.graduationYear || !data.degreeType || !data.startYear) {
            return createResponse(false, null, null, 'Please fill in all required degree fields')
        }

        if (data.degreeName.trim() === "" || data.institution.trim() === ""|| data.degreeType.trim() === ""){
            return createResponse(false, null, null, 'Please fill in all required degree fields')
        }

        if (data.universityUrl && !this.isValidUrl(data.universityUrl)) {
            return createResponse(false, null, null, 'Please enter a valid URL')
        }

        if (data.startYear > data.graduationYear) {
            return createResponse(false, null, null, 'Start year cannot be after graduation year')
        }

        return this.dao.insertDegree(userId, data)
    }

    async deleteEntry(req) {
    const { tableName, entryId } = req.body
    const userId = req.user.userID

    const allowedTables = ['degrees', 'certifications', 'licences', 'short_courses', 'employment_history']
    if (!allowedTables.includes(tableName)) {
        return createResponse(false, null, null, 'Invalid table')
    }

    return await this.dao.deleteEntry(tableName, entryId, userId)
}
    

    validateAndInsertCertification(userId, data) {
        if (!data.certName || !data.completionDate) {
            return createResponse(false, null, null, 'Please fill in all required certification fields')
        }

        if (data.courseUrl && !this.isValidUrl(data.courseUrl)) {
            return createResponse(false, null, null, 'Please enter a valid URL')
        }

        return this.dao.insertCertification(userId, data)
    }

    validateAndInsertLicence(userId, data) {
        if (!data.licenceName || !data.completionDate) {
            return createResponse(false, null, null, 'Please fill in all required licence fields')
        }

        if (data.licenceName.trim() === "" || data.completionDate.trim() === ""){
            return createResponse(false, null, null, 'Please fill in all required licence fields')
        }

        if (data.awardingBodyUrl && !this.isValidUrl(data.awardingBodyUrl)) {
            return createResponse(false, null, null, 'Please enter a valid URL')
        }

        return this.dao.insertLicence(userId, data)
    }

    validateAndInsertCourse(userId, data) {
        if (!data.courseName || !data.completionDate) {
            return createResponse(false, null, null, 'Please fill in all required course fields')
        }

        if (data.courseName.trim() === ""){
            return createResponse(false, null, null, 'Please fill in all course licence fields')
        }

        if (data.courseUrl && !this.isValidUrl(data.courseUrl)) {
            return createResponse(false, null, null, 'Please enter a valid URL')
        }

        return this.dao.insertCourse(userId, data)
    }

    validateAndInsertEmployment(userId, data) {
        if (!data.companyName || !data.role || !data.startDate) {
            return createResponse(false, null, null, 'Please fill in all required employment fields')
        }
        if (data.companyName.trim() === "" || data.role.trim() === ""){
            return createResponse(false, null, null, 'Please fill in all required Employment fields')
        }

        if (data.endDate && data.startDate > data.endDate) {
            return createResponse(false, null, null, 'Start date cannot be after end date')
        }

        return this.dao.insertEmployment(userId, data)
    }

    isValidUrl(string) {
        try {
            new URL(string)
            return true
        } catch {
            return false
        }
    }



    async resetMonthlyAppearanceCount(){
        return await this.dao.resetMonthlyAppearanceCount()
    }

}

module.exports = alumniservice
