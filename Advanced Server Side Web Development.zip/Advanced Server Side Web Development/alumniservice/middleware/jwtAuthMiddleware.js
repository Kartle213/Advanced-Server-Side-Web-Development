const JWT_SECRET = process.env.JWT_SECRET
const createResponse = require('../../shared-utils/reponse')
const bearerToken = require('../../shared-utils/bearerToken')

const validateJWT = async (req,res,next) =>{
    try {   
        const token = req.cookies?.['access-token'] || req.headers['authorization']?.replace('Bearer ', '')
       
    

        if (!token){
            console.log('No token, redirecting to login')
            return  res.redirect('/ui/login')
        }

        const decoded = await bearerToken.verifyAccessToken(token)

        if (!decoded){
            return createResponse(false,null,null,"Invalid token")
        }

        req.user = decoded
        next()

    }catch (error) {
    if (error.name === 'TokenExpiredError') {
        const refreshToken = req.cookies?.['refresh-token']

        if (!refreshToken) {
            return res.redirect('/ui/login')
        }

        try {
            const decoded = await bearerToken.verifyRefreshToken(refreshToken)

            if (!decoded) {
                return res.redirect('/ui/login')
            }

            console.log('Refresh token valid, generating new access token for user:', decoded) // Log the user information to see what is being passed in

            const newTokens = await bearerToken.generateToken({
                userID: decoded.userID || decoded.id,
                email: decoded.email,
                userType: decoded.userType
            })

            res.cookie('access-token', newTokens.accessToken, {
                httpOnly: true,
                secure: false,
                sameSite: 'lax',
                maxAge: 15 * 60 * 1000
            })

            req.user = decoded
            return next()
        } catch (refreshError) {
            return res.redirect('/ui/login')
        }
    }

    return res.redirect('/ui/login')
}
}

module.exports = validateJWT