const apikeydao = require('../daos/apikeydao')

class apikeyservice {
    constructor() {
        this.apikey = new apikeydao()
    }

    async create(userId, keyType) {
        return await this.apikey.create(userId, keyType)
    }

    async getKeyByUserId(userId) {
        return await this.apikey.getKeyByUserId(userId)
    }

    async revokeKey(userId) {
        return await this.apikey.revokeKey(userId)
    }

    async regenerateKey(userId, keyType) {
        return await this.apikey.regenerateKey(userId, keyType)
    }

    async getByKey(key) {
        return await this.apikey.getByValidKey(key)
    }

    async getAllKeys() {
        return await this.apikey.getAllKeys()
    }
}

module.exports = apikeyservice