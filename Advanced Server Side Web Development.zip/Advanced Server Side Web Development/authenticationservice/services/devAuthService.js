const hashService = require('../../shared-utils/hashService')

const axios = require('axios')
require('dotenv').config()

const BASE_URL = process.env.BASE_URL
const AUTH_SERVICE_API_KEY = process.env.SERVICE_API_KEY

const devAuthClient = axios.create({
    baseURL: BASE_URL,
    headers: {
        'x-api-key': AUTH_SERVICE_API_KEY,
        'Content-Type': 'application/json'
    }
})

const registerDeveloper = async (fn, sn, email, password) => {
    console.log(BASE_URL)
    console.log(AUTH_SERVICE_API_KEY)
    try {
        const response = await devAuthClient.post('/user/create', {
    fn, sn, email, password,
    userType: 'DEVELOPER'
})


return response.data
   } catch (error) {
    
    return { success: false, error: 'Registration failed' }
}
}

const loginDeveloper = async (email, password) => {
    try {
        const response = await devAuthClient.post('/user/retrieveByEmail', {
            email, password
        })
        return response.data
    } catch (error) {
        console.error('Dev auth error:', error.response?.data || error.message)
        return { success: false, error: 'Login failed' }
    }
}

module.exports = { registerDeveloper, loginDeveloper }