const express = require('express');
const app = express();
require('dotenv').config()
const PORT = process.env.PORT;

app.use(express.json())
const userRouter = require("./routes/userroute")
const apikeyRouter = require("./routes/apikeyroute");
const devRouter = require("./routes/devroute")
const {genericAPIKeyMiddleware} = require('./middleware/apikeyvalidator');
const swaggerUI = require('swagger-ui-express')
const swaggerSpec = require('./swagger')
const cookieparser = require('cookie-parser')



const rateLimit = require('express-rate-limit')

const limiter = rateLimit({
    windowMs: 15*60*1000,
    max: 200,
    //message: "Too many requests from this IP, please try again after 15 minutes"
})

app.use(limiter) 
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
app.use(cookieparser())
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec))
app.use("/user",genericAPIKeyMiddleware, userRouter)
app.use("/apikey",apikeyRouter)
app.use("/dev" , devRouter)

