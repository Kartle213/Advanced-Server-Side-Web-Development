const bcrypt = require('bcrypt')

const saltRounds = 10 
const encrypt = async(password) =>{
    return await bcrypt.hash(password,saltRounds)
}

const verify = async(passwordFromUser, hashedPasswordFromDB) =>{
    return await bcrypt.compare(passwordFromUser,hashedPasswordFromDB)
}

module.exports = {encrypt , verify}