const express = require('express')
const router = express.Router()
const path = require('path')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')
const { loginDeveloper, registerDeveloper } = require('../services/devAuthService')
const { generateToken } = require('../../shared-utils/bearerToken')
const createResponse = require('../../shared-utils/reponse')
const apikeyservice = require('../services/apikeyservice')

router.get('/', async (req, res) => {
    res.redirect('/dev/login')
})

router.get('/register', async (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'devregister.html'))
})

router.get('/login', async (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'devlogin.html'))
})

router.get('/dashboard', jwtAuthMiddleware, async (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'devdashboard.html'))
})

router.get('/logout', async (req, res) => {
    res.clearCookie('access-token')
    res.clearCookie('refresh-token')
    res.redirect('/dev/login')
})

router.post('/register', async (req, res) => {
    try {
        const { fn, sn, email, password } = req.body
        const result = await registerDeveloper(fn, sn, email, password)

        if (!result.success || !result.data) {
            return res.status(400).json(result)
        }

       
        const keyService = new apikeyservice()
        const userData = result.data.data || result.data
        const keyResult = await keyService.create(userData.id, 'WEB')

        res.json(createResponse(true, {
            user: userData,
            apiKey: keyResult.success ? keyResult.data.apiKey : null
        }))
    } catch (error) {
        console.error('Dev register error:', error.message)
        res.status(500).json(createResponse(false, null, null, 'Registration failed'))
    }
})

router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body
        const result = await loginDeveloper(email, password)

        if (!result.success || !result.data) {
            return res.status(401).json(createResponse(false, null, null, 'Login failed'))
        }

        const userData = result.data.data || result.data

        const token = await generateToken({
            userID: userData.id,
            email: userData.email,
            userType: userData.userType
        })

        res.cookie('access-token', token.accessToken, {
            httpOnly: true,
            secure: false,
            sameSite: 'lax',
            maxAge: 15 * 60 * 1000
        })

        res.cookie('refresh-token', token.refreshToken, {
            httpOnly: true,
            secure: false,
            sameSite: 'lax',
            maxAge: 7 * 24 * 60 * 60 * 1000
        })

        res.json(createResponse(true, { message: 'Login successful' }))
    } catch (error) {
        console.error('Dev login error:', error.message)
        res.status(500).json(createResponse(false, null, null, 'Login failed'))
    }
})

router.get('/apikey', jwtAuthMiddleware, async (req, res) => {
    try {
        const keyService = new apikeyservice()
        const result = await keyService.getKeyByUserId(req.user.userID)

        if (!result.success) {
            return res.json(createResponse(false, null, null, 'No API key found'))
        }

        res.json(createResponse(true, { apiKey: result.data.apikey }))
    } catch (error) {
        res.status(500).json(createResponse(false, null, null, 'Failed to get API key'))
    }
})

router.get('/usage', jwtAuthMiddleware, async (req, res) => {
    try {
        const keyService = new apikeyservice()
        const keyResult = await keyService.getKeyByUserId(req.user.userID)

        if (!keyResult.success) {
            return res.json(createResponse(true, {
                totalRequests: 0,
                todayRequests: 0,
                revoked: false,
                recentActivity: []
            }))
        }

        
        res.json(createResponse(true, {
            totalRequests: 0,
            todayRequests: 0,
            revoked: keyResult.data.isActive === 0,
            recentActivity: []
        }))
    } catch (error) {
        res.status(500).json(createResponse(false, null, null, 'Failed to get usage stats'))
    }
})

router.post('/regenerate-key', jwtAuthMiddleware, async (req, res) => {
    try {
        const keyService = new apikeyservice()
        const result = await keyService.regenerateKey(req.user.userID, 'WEB')

        if (!result.success) {
            return res.status(400).json(result)
        }

        res.json(createResponse(true, { apiKey: result.data.apiKey }))
    } catch (error) {
        res.status(500).json(createResponse(false, null, null, 'Failed to regenerate key'))
    }
})

router.post('/revoke-key', jwtAuthMiddleware, async (req, res) => {
    try {
        const keyService = new apikeyservice()
        const result = await keyService.revokeKey(req.user.userID)

        if (!result.success) {
            return res.status(400).json(result)
        }

        res.json(createResponse(true, null, null, 'Key revoked'))
    } catch (error) {
        res.status(500).json(createResponse(false, null, null, 'Failed to revoke key'))
    }
})

module.exports = router