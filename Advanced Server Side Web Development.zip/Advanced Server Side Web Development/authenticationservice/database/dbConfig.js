const db = require('sqlite3')
const connection = new db.Database('./auth.db' , (err) =>{
    if (err){
        console.error('Failed to connect to database!')
    }
    else{
        console.log('DB Connection Success')
    }
})

const dropTable = (tablename) =>{
    connection.run(`DROP TABLE ${tablename}`,(err) =>{
            if(err){
                console.error(`Error when dropping table ${tablenam}`)
            }
            else{
                console.log(`Table ${tablename} Successfully Dropped`)}
            })
}

//User Table


const createUserTable = () =>{
    connection.run(
        `create table IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fn TEXT NOT NULL,
        sn TEXT NOT NULL,
        password TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        userType TEXT NOT NULL,
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,(err) =>{
            if(err){
                console.error(err)
            }
            else{
                console.log("Table Users Successfully Created")}
            }
    )
}

//API table


const createAPITable = () =>{
    connection.run(`
        CREATE TABLE IF NOT EXISTS api_keys(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            apiKey TEXT NOT NULL UNIQUE,
            userId INTEGER NOT NULL,
            keyType TEXT NOT NULL CHECK(keyType IN ('AR','WEB')),
            isActive INTEGER NOT NULL DEFAULT 1,
            createdDate DATETIME DEFAULT CURRENT_TIMESTAMP,
            endDate DATETIME,
            FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        )`
        , (err) => {
            if(err){
                console.error(err)
            }
            else{
                console.log("Table API Keys Successfully created")
            }
        }) 
}



createAPITable();
createUserTable();

//dropTable();

module.exports = connection