const swaggerJSdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Authentication Service API',
      version: '1.0.0',
      description: 'API documentation for the Authentication Service',
    },
    servers: [{url: 'http://localhost:3000'}],
  },
  apis: ['./routes/*.js'], 

};

module.exports = swaggerJSdoc(options);