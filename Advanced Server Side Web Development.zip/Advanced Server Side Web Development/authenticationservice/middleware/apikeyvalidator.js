const apikeyserice = require("../services/apikeyservice")
const createResponse = require("../../shared-utils/reponse")

const SERVICE_API_KEY = process.env.SERVICE_API_KEY

const apikeyvalidate= (requiredScope) => async (req ,res,next) =>{

        const apikey = req.header("x-api-key")

        const referer = req.get('referer') || req.get('origin')
        const isLocalPage = referer && referer.includes(req.get('host'))

        console.log("API Key receiv IERWEFSDV", apikey)

        if (isLocalPage){
            return next()
        }

        if(!apikey){
            return res.status(401).json(createResponse(false,null,"Please Include API Key"))
        }

        if (apikey === SERVICE_API_KEY) {
            /* req.key = { keyType: 'SERVICE' } */
            console.log("Service API key validated successfully.")
        return next()
    }
        
        const service = new apikeyserice()
        
        try{
            
            const result = await service.getByValidKey(apikey)
            
            if(!result.success){
                return res.status(403).json(result.error)
            }
            if(!result.data.keyType == requiredScope){
                return res.status(403).json(result.error)
            }
            req.key = result.data
            next()

        }catch(ex){
            
        }

    
   
}

const arApikeyMiddleware = apikeyvalidate('AR')
const webApiKeyMiddleware = apikeyvalidate('WEB')
const genericAPIKeyMiddleware = apikeyvalidate()

module.exports = { arApikeyMiddleware , webApiKeyMiddleware,genericAPIKeyMiddleware}