const JWT_SECRET = process.env.JWT_SECRET
const createResponse = require('../../shared-utils/reponse')
const bearerToken = require('../../shared-utils/bearerToken')


    const validateJWT = async (req, res, next) => {
    const loginPath = req.originalUrl.startsWith('/dev') ? '/dev/login' : '/ui/login'

    try {
        const token = req.cookies?.['access-token'] || req.headers['authorization']?.replace('Bearer ', '')

        if (!token) {
            console.log('No token, redirecting to login')
            return res.redirect(loginPath)
        }

        const decoded = await bearerToken.verifyAccessToken(token)

        if (!decoded) {
            return res.redirect(loginPath)
        }

        req.user = decoded
        next()

    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            const refreshToken = req.cookies?.['refresh-token']

            if (!refreshToken) {
                return res.redirect(loginPath)
            }

            try {
                const decoded = await bearerToken.verifyRefreshToken(refreshToken)

                if (!decoded) {
                    return res.redirect(loginPath)
                }

                const newTokens = await bearerToken.generateToken({
                    userID: decoded.userID || decoded.id,
                    email: decoded.email,
                    userType: decoded.userType
                })

                res.cookie('access-token', newTokens.accessToken, {
                    httpOnly: true,
                    secure: false,
                    sameSite: 'lax',
                    maxAge: 15 * 60 * 1000
                })

                req.user = decoded
                return next()
            } catch (refreshError) {
                return res.redirect(loginPath)
            }
        }

        return res.redirect(loginPath)
    }
}

module.exports = validateJWT