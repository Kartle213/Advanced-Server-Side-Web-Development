const crypto = require('crypto')
const createResponse = require ('../../shared-utils/reponse')
const connection = require('../database/dbConfig')
class apikeydao{
    constructor(){}

    async create(req){
        const apikey = await crypto.randomBytes(32).toString('hex')
        return new Promise((resolve, reject) =>{
            const query = 'insert into api_keys (apikey, userId,keyType,endDate) values(?,?,?, datetime("now","+1 Month"))'
            connection.run(query, [apikey,req.userID, req.keyType], function(err){
                if(err){
                    return resolve(createResponse(false, null,null, err))
                }
                if(this.changes === 0){
                    return resolve(createResponse(false, null,null, "Faield to create key"))
                }
                resolve(createResponse(true, apikey))
            })

        })
    }
    async pullKeys()
    {
        
    }

  async getAllKeys() {
        return new Promise((resolve) => {
            const query = `SELECT * FROM api_keys`
            connection.all(query, [], (err, rows) => {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to get keys'))
                }
                return resolve(createResponse(true, rows))
            })
        })
    }

    async regenerateKey(userId, keyType) {
        const apikey = crypto.randomBytes(32).toString('hex')
        return new Promise((resolve) => {
            // Deactivate old key first
            connection.run(`UPDATE api_keys SET isActive = 0 WHERE userId = ? AND isActive = 1`, [userId], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to regenerate key'))
                }
                // Insert new key
                const query = `INSERT INTO api_keys (apikey, userId, keyType, endDate) VALUES (?, ?, ?, datetime('now', '+1 Month'))`
                connection.run(query, [apikey, userId, keyType], function(err) {
                    if (err) {
                        return resolve(createResponse(false, null, null, 'Failed to create new key'))
                    }
                    resolve(createResponse(true, { apiKey: apikey, id: this.lastID }))
                })
            })
        })
    }

     async getKeyByUserId(userId) {
        return new Promise((resolve) => {
            const query = `SELECT * FROM api_keys WHERE userId = ? AND isActive = 1 AND (endDate IS NULL OR endDate > datetime('now')) ORDER BY createdAt DESC LIMIT 1`
            connection.get(query, [userId], (err, row) => {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to get key'))
                }
                if (!row) {
                    return resolve(createResponse(false, null, null, 'No active key found'))
                }
                return resolve(createResponse(true, row))
            })
        })
    }

     async revokeKey(userId) {
        return new Promise((resolve) => {
            const query = `UPDATE api_keys SET isActive = 0 WHERE userId = ? AND isActive = 1`
            connection.run(query, [userId], function(err) {
                if (err) {
                    return resolve(createResponse(false, null, null, 'Failed to revoke key'))
                }
                if (this.changes === 0) {
                    return resolve(createResponse(false, null, null, 'No active key to revoke'))
                }
                return resolve(createResponse(true, null, null, 'Key revoked'))
            })
        })
    }

    async getByValidKey(key){
      
    return new Promise((resolve,reject) =>{
        const query = "SELECT apikey FROM api_keys WHERE apikey = ? and isActive = 1 AND (endDate IS NULL OR endDate > datetime('now'))"
        connection.run(query,[key],(err,rows) =>{
            
            if(err){
                return reject(createResponse(false,null,null,"There was an error when retrieving the key"))
            }
            if(!rows){
                return resolve(createResponse(false,null,null,"Invalid Key"))
            }
            return resolve(createResponse(true ,rows))
        })
    })
    }
}
module.exports = apikeydao