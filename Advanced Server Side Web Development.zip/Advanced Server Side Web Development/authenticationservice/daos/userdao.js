const createResponse = require("../../shared-utils/reponse")
const connection = require('../database/dbConfig')

class userdao{

    constructor(){

    }

    async createUser(req){
        
        return new Promise((resolve, reject) =>{

            connection.run(`insert into users (fn,sn,email,password,userType) 
                values(?,?,?,?,?)`, [req.body.fn, req.body.sn, req.body.email, req.body.password, req.body.userType], function(err){
                    if (err){
                        if (err.message.includes('UNIQUE constraint failed')) {
                            return resolve(createResponse(false, null, null, 'Email already registered'))
                        }
                        return resolve(createResponse(false,null,null," There was an error when creating the user "))
                    }
                    
                    if(this.changes === 0){

                        return resolve(createResponse(false,null,null," Insertion failed "))
                        
                    }

                    const userData = {
                        id: this.lastID,
                        email:req.body.email,
                        fn:req.body.fn,
                        sn:req.body.sn

                    }

                    return resolve(createResponse(true, userData))

                })

        })

    }

  

    async retrieveByEmail(email){
            return new Promise((resolve,reject) =>{
          
                const query = `select * from users where email = ?` 
                connection.get(query,[email],(err,rows)=>{
                    if(err){
                        return reject(createResponse(false,null,null,"There was an error when querying by email"))
                    }
                    if(!rows){
                        return resolve(createResponse(false,null,null,"No such user"))
                    }
                    console.log("UserDAO retrieved user:", rows)   
                    return resolve(createResponse(true,rows))
                })
            })
    }
     
    async retrieveAll(req){
       return new Promise((resolve,reject) =>{
                const query = `select * from users `
                connection.get(query,(err,rows)=>{
                    if(err){
                        return reject(createResponse(false,null,null,"There was an error when querying all users"))
                    }
                    if(!rows){
                        return reject(createResponse(false,null,null,"No users found"))
                    }
                    return resolve(createResponse(true,rows))
                })
            })
    }

    async updateUser(req){
        return new Promise((resolve,reject) =>{
            const query = `update users set fn = ?, sn = ?, password = ? where email = ?`
            connection.run(query,[req.body.fn, req.body.sn, req.body.password, req.body.email], function(err){
                if(err){
                    return reject(createResponse(false,null,null,"There was an error when updating"))
                }
                if(this.changes === 0){
                    return resolve(createResponse(false,null,null,"No such user"))
                }
                return resolve(createResponse(true,null))
            })
        })
    }

    async deleteUserWithID(req){

        return new Promise(resolve,reject =>{  
            const query = `delete from users where id = ?`
            connection.run(query,[req.body.id], function(err){
                if(err){
                    return reject(createResponse(false,null,null,"There was an error when deleting"))
                }
                if(this.changes === 0){
                    return resolve(createResponse(false,null,null,"No such user"))
                }
                return resolve(createResponse(true,null))
            })
        })
    }
}

module.exports = userdao