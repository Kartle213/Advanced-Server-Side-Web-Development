const swaggerJSdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Analytics Dashboard API',
      version: '1.0.0',
      description: 'API documentation for the University Analytics Dashboard',
    },
    servers: [{url: 'http://localhost:3002'}],
  },
  apis: ['./routes/*.js'], 

};

module.exports = swaggerJSdoc(options);