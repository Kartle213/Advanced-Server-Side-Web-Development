const {register , login } = require('./authServiceClient')
const createResponse = require('../../shared-utils/reponse')
const { generateToken } = require('../../shared-utils/bearerToken')
const { updatePassword } = require('../services/authServiceClient')

class userservice {
    constructor(){
     


    }
    async create(req){

        const fn = req.body.fn
        const sn = req.body.sn
        const password = req.body.password
        const email = req.body.email
        const confirmPassword = req.body.confirmPassword    

        const emailDomain = email.split('@')[1]?.toLowerCase()
        const allowedDomains = ['westminster.ac.uk', 'eastminster.ac.uk']

        if (!emailDomain || !allowedDomains.includes(emailDomain)) {
            return createResponse(false, null, null, "Please use a valid university email address")
        }

         if (!fn || !sn || !password || !email){
            
            return createResponse(false,null,null,"Please fill in all fields")
        }

        if(fn.trim() === '' || sn.trim() === '' || email.trim() === '' || password.trim() === ''){
            return createResponse(false,null,null,"Please fill in all fields")
        }

        if (password.length < 8){
            return createResponse(false,null,null,"Password should be more then eight characters long")
        }


        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(password)) {
            return createResponse(false,null,null,"Password must contain at least one uppercase letter and one special character")
        }

        if (password !== confirmPassword){
            return createResponse(false,null,null,"Passwords do not match")
        }
        
        const reponse = await register(req)

        console.log("Register response2:", reponse)
        if (!reponse || !reponse.success){
            return createResponse(false,null,null,"Failed to register user")
        }


        return reponse

    }

    async retrieveByEmail(req){

        const email = req.body.email
        const password = req.body.password


        if (!email || !password){
            return createResponse(false,null,null,"Please fill in all fields")
        }
        
        if (email.trim() === '' || password.trim() === ''){
            return createResponse(false,null,null,"Invalid credentials")
        }

      

        const response = await login(req)

        if (!response.success || !response.data) {
            return createResponse(false, null, null, response.error || 'Login failed')
        }

        console.log("Login response:", response)

        const token = await generateToken(response.data)



        return createResponse(
            true,
            {
            user:response.data,
            accessToken: token.accessToken,
            refreshToken: token.refreshToken
        })

    }

    async updateProfile(req) {
    const { tableName, data } = req.body
    const userId = req.user.userID

  
    const profile = await this.dao.retrieveByID(userId)
    if (!profile.success || !profile.data) {
        return createResponse(false, null, null, 'Profile not found')
    }

    const profileId = profile.data.id

    switch (tableName) {
        case 'degrees':
            return this.validateAndInsertDegree(profileId, data)
        case 'certifications':
            return this.validateAndInsertCertification(profileId, data)
        case 'licences':
            return this.validateAndInsertLicence(profileId, data)
        case 'short_courses':
            return this.validateAndInsertCourse(profileId, data)
        case 'employment_history':
            return this.validateAndInsertEmployment(profileId, data)
        default:
            return createResponse(false, null, null, 'Invalid table name')
    }
    }

    async getProfile(userID){
        return await this.dao.getFullProfile(userID)
    }

   async generateToken(){

   }

   async resetPassword(req){
    
        return await updatePassword(req)
   }

}

module.exports = userservice