const alumniClient = require('./alumniServiceClient');

class dataservice {

    
    async getFilteredAlumniIds(filters = {}) {
        if (!filters.programme && !filters.year) return null;

        const degrees = await alumniClient.getAllDegrees();
        return degrees
            .filter(d => {
                if (filters.programme && !d.degreeName.includes(filters.programme)) return false;
                if (filters.year && !d.completionDate.startsWith(filters.year)) return false;
                return true;
            })
            .map(d => d.alumnusId);
    }

  
    async getFilteredCurrentJobs(filters = {}) {
        const employment = await alumniClient.getAllEmployment();
        const filteredIds = await this.getFilteredAlumniIds(filters);

        let currentJobs = employment.filter(e => !e.endDate);
        if (filteredIds) {
            currentJobs = currentJobs.filter(e => filteredIds.includes(e.alumnusId));
        }
        return currentJobs;
    }

    async getStats() {
        const alumni = await alumniClient.getAllAlumni();
        const certs = await alumniClient.getAllCertifications();
        const degrees = await alumniClient.getAllDegrees();
        const aotd = await alumniClient.getAlumniOfTheDay();

        const programmes = [...new Set(degrees.map(d => d.degreeName))];

        return {
            totalAlumni: alumni.length,
            totalCerts: certs.length,
            totalProgrammes: programmes.length,
            currentAOTD: aotd?.fn ? `${aotd.fn} ${aotd.sn}` : 'None today'
        };
    }

    async getCertifications(filters = {}) {
        const alumni = await alumniClient.getAllAlumni();
        const certs = await alumniClient.getAllCertifications();
        const filteredIds = await this.getFilteredAlumniIds(filters);

        const alumniIds = filteredIds || alumni.map(a => a.id);
        if (alumniIds.length === 0) return { labels: [], values: [] };

        const certCounts = {};
        certs.filter(c => alumniIds.includes(c.alumnusId)).forEach(c => {
            if (!certCounts[c.certName]) certCounts[c.certName] = new Set();
            certCounts[c.certName].add(c.alumnusId);
        });

        const sorted = Object.entries(certCounts)
            .map(([name, holders]) => ({ label: name, value: Math.round((holders.size / alumniIds.length) * 100) }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 10);

        return { labels: sorted.map(s => s.label), values: sorted.map(s => s.value) };
    }

    async getAlumniBySector(filters = {}) {
        const jobs = await this.getFilteredCurrentJobs(filters);

        const counts = {};
        jobs.forEach(e => { counts[e.sector || 'Other'] = (counts[e.sector || 'Other'] || 0) + 1; });

        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
        return { labels: sorted.map(s => s[0]), values: sorted.map(s => s[1]) };
    }

    async getCareerPathways(filters = {}) {
        const jobs = await this.getFilteredCurrentJobs(filters);

        const counts = {};
        jobs.forEach(e => { counts[e.role] = (counts[e.role] || 0) + 1; });

        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10);
        return { labels: sorted.map(s => s[0]), values: sorted.map(s => s[1]) };
    }

    async getTopEmployers(filters = {}) {
        const jobs = await this.getFilteredCurrentJobs(filters);

        const counts = {};
        jobs.forEach(e => { counts[e.companyName] = (counts[e.companyName] || 0) + 1; });

        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10);
        return { labels: sorted.map(s => s[0]), values: sorted.map(s => s[1]) };
    }

    async getGeographic(filters = {}) {
        const alumni = await alumniClient.getAllAlumni();
        const filteredIds = await this.getFilteredAlumniIds(filters);

        const filtered = filteredIds ? alumni.filter(a => filteredIds.includes(a.id)) : alumni;

        const counts = {};
        filtered.forEach(a => { counts[a.region || 'Unknown'] = (counts[a.region || 'Unknown'] || 0) + 1; });

        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
        return { labels: sorted.map(s => s[0]), values: sorted.map(s => s[1]) };
    }

    async getGraduationTrends(filters = {}) {
        const degrees = await alumniClient.getAllDegrees();

        let filtered = degrees;
        if (filters.programme) filtered = filtered.filter(d => d.degreeName.includes(filters.programme));

        const counts = {};
        filtered.forEach(d => { const y = d.completionDate.substring(0, 4); counts[y] = (counts[y] || 0) + 1; });

        const sorted = Object.entries(counts).sort((a, b) => a[0] - b[0]);
        return { labels: sorted.map(s => s[0]), values: sorted.map(s => s[1]) };
    }

    async getTechAdoption(filters = {}) {
        const certs = await alumniClient.getAllCertifications();
        const degrees = await alumniClient.getAllDegrees();
        const tracked = ['AWS', 'Docker', 'Kubernetes', 'Azure', 'Scrum'];

        const yearMap = {};
        degrees.forEach(d => {
            if (filters.programme && !d.degreeName.includes(filters.programme)) return;
            yearMap[d.alumnusId] = d.completionDate.substring(0, 4);
        });

        const years = [...new Set(Object.values(yearMap))].sort();

        const datasets = tracked.map(cert => ({
            label: cert,
            values: years.map(year => {
                const ids = Object.entries(yearMap).filter(([_, y]) => y === year).map(([id]) => parseInt(id));
                const count = certs.filter(c => c.certName.toLowerCase().includes(cert.toLowerCase()) && ids.includes(c.alumnusId)).length;
                return ids.length > 0 ? Math.round((count / ids.length) * 100) : 0;
            })
        }));

        return { labels: years, datasets };
    }

    async getProgrammes() {
        const degrees = await alumniClient.getAllDegrees();
        return { labels: [...new Set(degrees.map(d => d.degreeName))].sort() };
    }

    async getGraduationYears() {
        const degrees = await alumniClient.getAllDegrees();
        return { years: [...new Set(degrees.map(d => d.completionDate.substring(0, 4)))].sort().reverse() };
    }

    async getAlumniList(filters = {}) {
        const alumni = await alumniClient.getAllAlumni();
        const degrees = await alumniClient.getAllDegrees();
        const employment = await alumniClient.getAllEmployment();
        const certs = await alumniClient.getAllCertifications();

        let results = alumni.map(a => {
            const degree = degrees.find(d => d.alumnusId === a.id);
            const job = employment.find(e => e.alumnusId === a.id && !e.endDate);
            return {
                name: `${a.fn} ${a.sn}`,
                programme: degree?.degreeName || 'Unknown',
                graduationYear: degree?.completionDate.substring(0, 4) || 'Unknown',
                sector: job?.sector || 'Unknown',
                certCount: certs.filter(c => c.alumnusId === a.id).length
            };
        });

        if (filters.programme) results = results.filter(r => r.programme.toLowerCase().includes(filters.programme.toLowerCase()));
        if (filters.year) results = results.filter(r => r.graduationYear === filters.year);
        if (filters.sector) results = results.filter(r => r.sector.toLowerCase().includes(filters.sector.toLowerCase()));

        return { alumni: results };
    }
}

module.exports = dataservice;