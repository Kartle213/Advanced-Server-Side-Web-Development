const axios = require('axios');
require('dotenv').config();

const alumniClient = axios.create({
    baseURL: process.env.ALUMNI_SERVICE_URL,
    headers: {
        'x-api-key': process.env.ALUMNI_API_KEY,
        'Content-Type': 'application/json'
    }
});

const getAllAlumni = async () => {
    console.log("herer!!1")
    try {
        const response = await alumniClient.get('/alumni/all');
        return response.data;
    } catch (err) {
        console.log('Alumni client error:', err.message);
        console.log('Error response:', err.response?.status, err.response?.data);
        throw err;
    }
};

const getAllCertifications = async () => {
    const response = await alumniClient.get('/alumni/certifications');
    return response.data;
};

const getAllDegrees = async () => {
    const response = await alumniClient.get('/alumni/degrees');
    return response.data;
};

const getAllEmployment = async () => {
    const response = await alumniClient.get('/alumni/employment');
    return response.data;
};

const getAlumniOfTheDay = async () => {
    const response = await alumniClient.get('/alumni/alumni-of-the-day');
    return response.data;
};

module.exports = { getAllAlumni, getAllCertifications, getAllDegrees, getAllEmployment, getAlumniOfTheDay };