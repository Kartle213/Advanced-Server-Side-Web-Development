const { Parser } = require('json2csv')
const PDFDocument = require('pdfkit')
const dataservice = require('./dataservice')

class ExportService {

    constructor() {
        this.data = new dataservice()
    }

    async generateCSV(type, filters) {
        const methodMap = {
            'alumni': () => this.data.getAlumniList(filters),
            'certifications': () => this.data.getCertifications(filters),
            'sectors': () => this.data.getAlumniBySector(filters),
            'career-pathways': () => this.data.getCareerPathways(filters),
            'top-employers': () => this.data.getTopEmployers(filters),
            'geographic': () => this.data.getGeographic(filters)
        }

        if (!methodMap[type]) throw new Error('Invalid type')

        const result = await methodMap[type]()

       
        if (type === 'alumni') {
            return { csv: new Parser().parse(result.alumni), filename: 'alumni.csv' }
        }

      
        const rows = result.labels.map((label, i) => ({ label, value: result.values[i] }))
        return { csv: new Parser().parse(rows), filename: `${type}.csv` }
    }

    async generatePDF(filters) {
        const stats = await this.data.getStats()
        const sections = [
            { title: 'Certifications', data: await this.data.getCertifications(filters) },
            { title: 'Employment by Sector', data: await this.data.getAlumniBySector(filters) },
            { title: 'Job Titles', data: await this.data.getCareerPathways(filters) },
            { title: 'Top Employers', data: await this.data.getTopEmployers(filters) },
            { title: 'Geographic Distribution', data: await this.data.getGeographic(filters) }
        ]
 
        // basically just setting up the doc
        const doc = new PDFDocument({ margin: 50 })

        doc.fontSize(20).font('Helvetica-Bold').text('Alumni Analytics Report', { align: 'center' })
        doc.fontSize(9).font('Helvetica').fillColor('#888')
            .text(`Generated: ${new Date().toLocaleDateString('en-GB')}`, { align: 'center' })
        doc.moveDown(1.5)

        doc.fontSize(12).font('Helvetica-Bold').fillColor('#000').text('Overview')
        doc.fontSize(10).font('Helvetica').fillColor('#333')
        doc.text(`Alumni: ${stats.totalAlumni} | Certifications: ${stats.totalCerts} | Programmes: ${stats.totalProgrammes}`)
        doc.moveDown(1)

        sections.forEach(({ title, data }) => {
            if (doc.y > 650) doc.addPage()
            doc.fontSize(12).font('Helvetica-Bold').fillColor('#000').text(title)
            doc.fontSize(10).font('Helvetica').fillColor('#333')
            data.labels.forEach((label, i) => doc.text(`${label}: ${data.values[i]}`))
            doc.moveDown(1)
        })

        return doc
    }
}

module.exports = ExportService