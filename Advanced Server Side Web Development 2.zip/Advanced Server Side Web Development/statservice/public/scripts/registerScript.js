document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btnRegister').addEventListener('click', async (e) =>{
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const fn = document.getElementById('fn').value;
        const sn = document.getElementById('sn').value;
      

      


        if (!email || !password || !confirmPassword || !fn || !sn) {
            alert('Please fill in all fields.');
            return;
        }

         const emailDomain = email.split('@')[1]?.toLowerCase()
         const allowedDomains = ['westminster.ac.uk', 'eastminster.ac.uk']

         if (!emailDomain || !allowedDomains.includes(emailDomain)) {
             alert('Please use a valid university email address.');
             return;
         }

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        if(password.trim().length < 8){
            alert('Password must be at least 8 characters long.');
            return;
        }

        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(password)) {
            alert('Password must contain at least one uppercase letter and one special character.');
            return;
        }

        

        const userData = {
            email: email,
            password: password,
            confirmPassword: confirmPassword,
            fn: fn,
            sn: sn,
         
        }

        const csrfRequest = await fetch('/user/csrf-token')

        const {csrfToken} = await csrfRequest.json()

        const response = await fetch('/user/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-csrf-token': csrfToken
            },
            body: JSON.stringify(userData)
        });

        if (response.ok) {
            alert('Registration successful! Please log in.');
            window.location.href = '/ui/login';
        } else {
            const errorData = await response.json();
            alert('Registration failed: ' + errorData.message);
        }
    })
})