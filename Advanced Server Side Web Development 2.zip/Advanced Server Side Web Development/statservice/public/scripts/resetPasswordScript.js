document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('btnReset').addEventListener('click', async () => {
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (!currentPassword || !newPassword || !confirmPassword) {
            return alert('Please fill in all fields');
        }

        if (newPassword.length < 8) {
            return alert('New password must be at least 8 characters');
        }

        if (newPassword !== confirmPassword) {
            return alert('New passwords do not match');
        }

        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(currentPassword)) {
            return alert("Password must contain at least one uppercase letter and one special character")
        }

        if (currentPassword === newPassword) {
            return alert('New password must be different from current password');
        }



        try {
            console.log("here 0")
            const csrfRes = await fetch('/user/csrf-token');
            const { csrfToken } = await csrfRes.json();
                console.log("here1")
            const res = await fetch('/user/reset-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-csrf-token': csrfToken
                    },
                body: JSON.stringify({ currentPassword, newPassword })
            });

            
            const data = await res.json();

            console.log(data)

            console.log("here2")

            if (res.ok) {
                alert(data.error || null );
                document.getElementById('resetForm').reset();
            } else {
                alert(data.message || 'Failed to update password');
            }
        } catch (err) {
            alert('Something went wrong. Please try again.');
        }
    });

    document.getElementById('logoutBtn').addEventListener('click', async (e) => {
        e.preventDefault();
        await fetch('/user/logout', { method: 'POST' });
        window.location.href = '/ui/login';
    });




});