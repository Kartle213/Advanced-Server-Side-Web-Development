async function fetchData(endpoint) {
    try {
        const res = await fetch(endpoint);
        if (!res.ok) return null;
        return await res.json();
    } catch (err) {
        console.error(`Error: ${endpoint}`, err);
        return null;
    }
}

function getFilterQuery() {
    const programme = document.getElementById('filterProgramme').value;
    const year = document.getElementById('filterYear').value;
    const sector = document.getElementById('filterSector').value;
    const params = new URLSearchParams();
    if (programme) params.set('programme', programme);
    if (year) params.set('year', year);
    if (sector) params.set('sector', sector);
    const query = params.toString();
    return query ? `?${query}` : '';
}

function getSectorBadgeClass(sector) {
    const map = {
        'Technology & IT': 'tech',
        'Financial Services': 'finance',
        'Consulting': 'consulting',
        'Healthcare': 'healthcare',
        'Media & Entertainment': 'media',
        'Education': 'education',
        'Retail & E-commerce': 'retail',
        'Manufacturing': 'manufacturing'
    };
    return map[sector] || 'other';
}

async function loadAlumni() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/alumni-list${query}`);
    const tbody = document.getElementById('alumniBody');

    if (!data || !data.alumni || data.alumni.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
                        <line x1="18" y1="8" x2="23" y2="13"/><line x1="23" y1="8" x2="18" y2="13"/>
                    </svg>
                    <p>No alumni found matching your filters</p>
                </td>
            </tr>`;
        document.getElementById('resultCount').textContent = '0';
        return;
    }

    document.getElementById('resultCount').textContent = data.alumni.length;

    tbody.innerHTML = data.alumni.map(a => `
        <tr>
            <td>${a.name}</td>
            <td>${a.programme}</td>
            <td>${a.graduationYear}</td>
            <td><span class="badge ${getSectorBadgeClass(a.sector)}">${a.sector}</span></td>
            <td>${a.certCount}</td>
        </tr>
    `).join('');
}

async function loadFilters() {
    const programmes = await fetchData('/data/programmes');
    if (programmes) {
        const select = document.getElementById('filterProgramme');
        select.length = 1;
        programmes.labels.forEach(prog => {
            const opt = document.createElement('option');
            opt.value = prog;
            opt.textContent = prog;
            select.appendChild(opt);
        });
    }

    const years = await fetchData('/data/graduation-years');
    if (years) {
        const select = document.getElementById('filterYear');
        select.length = 1;
        years.years.forEach(year => {
            const opt = document.createElement('option');
            opt.value = year;
            opt.textContent = year;
            select.appendChild(opt);
        });
    }

    const sectors = await fetchData('/data/alumni-by-sector');
    if (sectors) {
        const select = document.getElementById('filterSector');
        select.length = 1;
        sectors.labels.forEach(sector => {
            const opt = document.createElement('option');
            opt.value = sector;
            opt.textContent = sector;
            select.appendChild(opt);
        });
    }
}

function applyFilters() {
    loadAlumni();
}

function resetFilters() {
    document.getElementById('filterProgramme').value = '';
    document.getElementById('filterYear').value = '';
    document.getElementById('filterSector').value = '';
    loadAlumni();
}

function exportCSV() {
    const query = getFilterQuery();
    window.location.href = `/export/csv/alumni${query}`;
}

function exportPDF() {
    const query = getFilterQuery();
    window.location.href = `/export/pdf${query}`;
}

document.getElementById('logoutBtn').addEventListener('click', async (e) => {
    e.preventDefault();
    await fetch('/user/logout', { method: 'POST' });
    window.location.href = '/ui/login';
});

document.addEventListener('DOMContentLoaded', () => {
    loadFilters();
    loadAlumni();
});