
async function loadStats() {
    console.log("here")
    try {
        const res = await fetch('/data/stats');
        console.log("got here")
        if (!res.ok) return;
        const data = await res.json();

        document.getElementById('statAlumni').textContent = data.totalAlumni || '--';
        document.getElementById('statCerts').textContent = data.totalCerts || '--';
        document.getElementById('statProgrammes').textContent = data.totalProgrammes || '--';
        document.getElementById('statAOTD').textContent = data.currentAOTD || '--';
    } catch (err) {
        console.error('Failed to load stats:', err);
    }
}


document.getElementById('logoutBtn').addEventListener('click', async (e) => {

    await fetch('/ui/logout', { method: 'POST' });
   
});

document.addEventListener('DOMContentLoaded', loadStats);