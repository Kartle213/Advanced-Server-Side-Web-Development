

function getSeverityColor(value) {
    if (value > 70) return '#EF4444';
    if (value > 50) return '#F59E0B';
    if (value > 30) return '#F97316';
    return '#6B7280';
}

const PALETTE = ['#2563eb', '#16a34a', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316', '#6366f1', '#14b8a6'];


const charts = {}


async function fetchData(endpoint) {
    try {
        const res = await fetch(endpoint);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        alert("There was an error connecting")

        return null;
    }
}

async function loadProgrammeFilter() {
    const data = await fetchData('/data/programmes');
    if (!data) return;

    const select = document.getElementById('filterProgramme');
    data.labels.forEach(prog => {
        const option = document.createElement('option');
        option.value = prog;
        option.textContent = prog;
        select.appendChild(option);
    });
}

async function loadYearFilter() {
    const data = await fetchData('/data/graduation-years');
    if (!data) return;

    const select = document.getElementById('filterYear');
    data.years.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        select.appendChild(option);
    });
}


function getFilterQuery() {
    const programme = document.getElementById('filterProgramme').value;
    const year = document.getElementById('filterYear').value;
    const params = new URLSearchParams();
    if (programme) params.set('programme', programme);
    if (year) params.set('year', year);
    const query = params.toString();
    return query ? `?${query}` : '';
}


function destroyChart(id) {
    if (charts[id]) {
        charts[id].destroy();
        delete charts[id];
    }
}


async function loadSkillsGapChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/certifications${query}`);
    if (!data) return;

    destroyChart('skillsGapChart');

    const colors = data.values.map(v => getSeverityColor(v));

    charts.skillsGapChart = new Chart(document.getElementById('skillsGapChart'), {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: '% of Alumni Acquiring Post-Graduation',
                data: data.values,
                backgroundColor: colors,
                borderWidth: 0,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const val = ctx.parsed.y;
                            let level = 'Monitor';
                            if (val > 70) level = 'Critical';
                            else if (val > 50) level = 'Significant';
                            else if (val > 30) level = 'Emerging';
                            return `${val}% of alumni — ${level} gap`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: { display: true, text: 'Percentage of Alumni (%)', font: { size: 12 } },
                    ticks: { callback: v => v + '%' }
                },
                x: {
                    title: { display: true, text: 'Certification', font: { size: 12 } },
                    ticks: { maxRotation: 45, minRotation: 45, font: { size: 11 } }
                }
            }
        }
    });
}


async function loadSectorChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/alumni-by-sector${query}`);
    if (!data) return;

    destroyChart('sectorChart');

    charts.sectorChart = new Chart(document.getElementById('sectorChart'), {
        type: 'pie',
        data: {
            labels: data.labels,
            datasets: [{
                data: data.values,
                backgroundColor: PALETTE.slice(0, data.labels.length),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { font: { size: 12 }, padding: 12 }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                            const pct = Math.round((ctx.parsed / total) * 100);
                            return `${ctx.label}: ${ctx.parsed} alumni (${pct}%)`;
                        }
                    }
                }
            }
        }
    });
}


async function loadJobTitlesChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/career-pathways${query}`);
    if (!data) return;

    destroyChart('jobTitlesChart');

    charts.jobTitlesChart = new Chart(document.getElementById('jobTitlesChart'), {
        type: 'doughnut',
        data: {
            labels: data.labels,
            datasets: [{
                data: data.values,
                backgroundColor: PALETTE.slice(0, data.labels.length),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { font: { size: 12 }, padding: 12 }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => {
                            const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                            const pct = Math.round((ctx.parsed / total) * 100);
                            return `${ctx.label}: ${ctx.parsed} alumni (${pct}%)`;
                        }
                    }
                }
            }
        }
    });
}


async function loadEmployersChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/top-employers${query}`);
    if (!data) return;

    destroyChart('employersChart');

    charts.employersChart = new Chart(document.getElementById('employersChart'), {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Number of Alumni',
                data: data.values,
                backgroundColor: '#6366f1',
                borderWidth: 0,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.parsed.x} alumni`
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    title: { display: true, text: 'Number of Alumni', font: { size: 12 } },
                    ticks: { stepSize: 1 }
                }
            }
        }
    });
}


async function loadGeoChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/geographic${query}`);
    if (!data) return;

    destroyChart('geoChart');

    charts.geoChart = new Chart(document.getElementById('geoChart'), {
        type: 'radar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Alumni Count',
                data: data.values,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.15)',
                pointBackgroundColor: '#2563eb',
                pointRadius: 4,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    ticks: { stepSize: 5, font: { size: 10 } },
                    pointLabels: { font: { size: 12 } }
                }
            }
        }
    });
}


async function loadTrendsChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/graduation-trends${query}`);
    if (!data) return;

    destroyChart('trendsChart');

    charts.trendsChart = new Chart(document.getElementById('trendsChart'), {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Graduates',
                data: data.values,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.08)',
                fill: true,
                tension: 0.3,
                pointRadius: 5,
                pointBackgroundColor: '#2563eb',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.parsed.y} graduates`
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Number of Graduates', font: { size: 12 } }
                },
                x: {
                    title: { display: true, text: 'Year', font: { size: 12 } }
                }
            }
        }
    });
}


async function loadTechAdoptionChart() {
    const query = getFilterQuery();
    const data = await fetchData(`/data/tech-adoption${query}`);
    if (!data) return;

    destroyChart('techAdoptionChart');

    const datasets = data.datasets.map((ds, i) => ({
        label: ds.label,
        data: ds.values,
        borderColor: PALETTE[i],
        backgroundColor: PALETTE[i] + '15',
        fill: true,
        tension: 0.3,
        pointRadius: 4,
        pointBackgroundColor: PALETTE[i],
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        borderWidth: 2
    }));

    charts.techAdoptionChart = new Chart(document.getElementById('techAdoptionChart'), {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { font: { size: 12 }, usePointStyle: true, padding: 16 }
                },
                tooltip: {
                    callbacks: {
                        label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y}%`
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: { display: true, text: 'Percentage of Alumni with Certification (%)', font: { size: 12 } },
                    ticks: { callback: v => v + '%' }
                },
                x: {
                    title: { display: true, text: 'Graduation Year', font: { size: 12 } }
                }
            }
        }
    });
}


async function applyFilters() {
    loadAllCharts();
}

async function resetFilters() {
    document.getElementById('filterProgramme').value = '';
    document.getElementById('filterYear').value = '';
    loadAllCharts();
}


async function exportChart(chartId) {
    const canvas = document.getElementById(chartId);
    const link = document.createElement('a');
    link.download = `${chartId}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
}

// maybe add to charts
async function exportCSV(chartId) {
    
}

async function loadAllCharts() {
    loadSkillsGapChart();
    loadSectorChart();
    loadJobTitlesChart();
    loadEmployersChart();
    loadGeoChart();
    loadTrendsChart();
    loadTechAdoptionChart();
}


document.getElementById('logoutBtn').addEventListener('click', async (e) => {
    e.preventDefault();
    await fetch('/ui/logout', { method: 'POST' });
    window.location.href = '/ui/login';
});


function applyFilters() {
    loadAllCharts(); 
}

document.addEventListener('DOMContentLoaded', () => {
    loadProgrammeFilter(); 
    loadYearFilter();      
    loadAllCharts();
});





