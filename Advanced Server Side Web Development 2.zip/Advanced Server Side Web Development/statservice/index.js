require('dotenv').config()
const express = require('express')
const app = express()
const PORT = process.env.PORT


const userrouter = require('./routes/userroute')
const uiRouter = require('./routes/uiroute')
const dataRouter = require('./routes/dataroute')
const exportRouter = require('./routes/exportroute')
const viewRouter = require('./routes/viewroute')
const cookieparser = require('cookie-parser')
const swaggerUI = require('swagger-ui-express')
const swaggerJSdoc = require('./swagger')

const rateLimit = require('express-rate-limit')

const limiter = rateLimit({
    windowMs: 15*60*1000,
    max: 200,
    //message: "Too many requests from this IP, please try again after 15 minutes"
})

app.use(limiter) 
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerJSdoc))
app.use(express.json())
app.use(express.static('public'))
app.use(cookieparser(process.env.COOKIE_SECRET))
app.use('/ui' , uiRouter)
app.use('/user' , userrouter)
app.use('/view', viewRouter)
app.use('/data' , dataRouter)
app.use('/export' ,exportRouter)

app.listen(PORT, (err) =>{

    if (err){
        console.error(err)
        
    }else{
        console.log(`Analytics Service Listening on Port ${PORT}`)
    }
})