const { doubleCsrf } = require('csrf-csrf')

const { generateCsrfToken, doubleCsrfProtection } = doubleCsrf({
    getSecret: () => process.env.CSRF_SECRET,
    cookieName: '__csrf',
    cookieOptions: {
        httpOnly: true,
        sameSite: 'strict',
        secure: false
    },
    getSessionIdentifier: (req) => req.session?.id || '',
    getTokenFromRequest: (req) => req.headers['x-csrf-token']
})

module.exports = { generateCsrfToken, doubleCsrfProtection }