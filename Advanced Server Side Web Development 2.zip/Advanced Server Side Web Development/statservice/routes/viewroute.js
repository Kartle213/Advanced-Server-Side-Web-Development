const express = require('express')
const router = express.Router()
const path = require('path')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')


router.get('/' , async (req , res) =>{

})



module.exports = router