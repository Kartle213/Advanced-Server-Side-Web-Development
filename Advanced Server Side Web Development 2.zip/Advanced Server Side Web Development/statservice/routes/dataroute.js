const express = require('express')
const router = express.Router()
const dataservice = require('../services/dataservice')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')



/**
 * @swagger
 * /data/stats:
 *   get:
 *     summary: Get dashboard statistics
 *     description: Returns total alumni, certifications, programmes, and alumni of the day
 *     responses:
 *       200:
 *         description: Dashboard statistics
 *       500:
 *         description: Server error
 */
router.get('/stats', jwtAuthMiddleware,async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getStats()
        res.json(result)
    } catch (err) {
        console.error('Stats error:', err.message)
        res.status(500).json({ message: 'Failed to fetch stats' })
    }
})

/**
 * @swagger
 * /data/certifications:
 *   get:
 *     summary: Get certification data for skills gap chart
 *     description: Returns percentage of alumni acquiring each certification post-graduation with severity levels
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: Certification data with labels and values arrays
 *       500:
 *         description: Server error
 */
router.get('/certifications', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getCertifications(req.query)
        res.json(result)
    } catch (err) {
        console.error('Certs error:', err.message)
        res.status(500).json({ message: 'Failed to fetch certifications' })
    }
})

/**
 * @swagger
 * /data/alumni-by-sector:
 *   get:
 *     summary: Get alumni employment by industry sector
 *     description: Returns count of alumni working in each industry sector
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: Sector data with labels and values arrays
 *       500:
 *         description: Server error
 */
router.get('/alumni-by-sector', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getAlumniBySector(req.query)
        res.json(result)
    } catch (err) {
        console.error('Sector error:', err.message)
        res.status(500).json({ message: 'Failed to fetch sectors' })
    }
})

/**
 * @swagger
 * /data/career-pathways:
 *   get:
 *     summary: Get most common job titles
 *     description: Returns top 10 job titles held by alumni
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: Job title data with labels and values arrays
 *       500:
 *         description: Server error
 */
router.get('/career-pathways', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getCareerPathways(req.query)
        res.json(result)
    } catch (err) {
        console.error('Career error:', err.message)
        res.status(500).json({ message: 'Failed to fetch career pathways' })
    }
})

/**
 * @swagger
 * /data/top-employers:
 *   get:
 *     summary: Get top employers of alumni
 *     description: Returns top 10 organisations employing the most alumni
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: Employer data with labels and values arrays
 *       500:
 *         description: Server error
 */
router.get('/top-employers', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getTopEmployers(req.query)
        res.json(result)
    } catch (err) {
        console.error('Employers error:', err.message)
        res.status(500).json({ message: 'Failed to fetch employers' })
    }
})

/**
 * @swagger
 * /data/geographic:
 *   get:
 *     summary: Get geographic distribution of alumni
 *     description: Returns count of alumni working in each region
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: Geographic data with labels and values arrays
 *       500:
 *         description: Server error
 */
router.get('/geographic', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getGeographic(req.query)
        res.json(result)
    } catch (err) {
        console.error('Geographic error:', err.message)
        res.status(500).json({ message: 'Failed to fetch geographic data' })
    }
})

/**
 * @swagger
 * /data/graduation-trends:
 *   get:
 *     summary: Get graduation trends over time
 *     description: Returns number of alumni graduating per year
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *     responses:
 *       200:
 *         description: Trend data with labels (years) and values (counts)
 *       500:
 *         description: Server error
 */
router.get('/graduation-trends', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getGraduationTrends(req.query)
        res.json(result)
    } catch (err) {
        console.error('Trends error:', err.message)
        res.status(500).json({ message: 'Failed to fetch trends' })
    }
})

/**
 * @swagger
 * /data/tech-adoption:
 *   get:
 *     summary: Get emerging technology adoption trends
 *     description: Returns certification adoption percentages across graduation years for AWS, Docker, Kubernetes, Azure, and Scrum
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *     responses:
 *       200:
 *         description: Multi-dataset with labels (years) and datasets array
 *       500:
 *         description: Server error
 */
router.get('/tech-adoption', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getTechAdoption(req.query)
        res.json(result)
    } catch (err) {
        console.error('Tech adoption error:', err.message)
        res.status(500).json({ message: 'Failed to fetch tech adoption' })
    }
})

/**
 * @swagger
 * /data/programmes:
 *   get:
 *     summary: Get distinct programme names
 *     description: Returns list of all programme names for filter dropdowns
 *     responses:
 *       200:
 *         description: Array of programme names
 *       500:
 *         description: Server error
 */
router.get('/programmes', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getProgrammes()
        res.json(result)
    } catch (err) {
        console.error('Programmes error:', err.message)
        res.status(500).json({ message: 'Failed to fetch programmes' })
    }
})

/**
 * @swagger
 * /data/graduation-years:
 *   get:
 *     summary: Get distinct graduation years
 *     description: Returns list of all graduation years for filter dropdowns
 *     responses:
 *       200:
 *         description: Array of years
 *       500:
 *         description: Server error
 */
router.get('/graduation-years', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getGraduationYears()
        res.json(result)
    } catch (err) {
        console.error('Years error:', err.message)
        res.status(500).json({ message: 'Failed to fetch years' })
    }
})

/**
 * @swagger
 * /data/alumni-list:
 *   get:
 *     summary: Get filterable alumni list
 *     description: Returns alumni with name, programme, graduation year, sector, and certification count
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *       - in: query
 *         name: sector
 *         schema:
 *           type: string
 *         description: Filter by industry sector
 *     responses:
 *       200:
 *         description: Array of alumni objects
 *       500:
 *         description: Server error
 */
router.get('/alumni-list', async (req, res) => {
    try {
        const service = new dataservice()
        const result = await service.getAlumniList(req.query)
        res.json(result)
    } catch (err) {
        console.error('Alumni list error:', err.message)
        res.status(500).json({ message: 'Failed to fetch alumni list' })
    }
})

module.exports = router