const express = require('express')
const router = express.Router()
const userservice = require('../services/userservice')
const jwtAuthMiddleware = require('../middleware/jwtAuthMiddleware')
const { generateCsrfToken, doubleCsrfProtection } = require('../middleware/csrf')
const { body, validationResult } = require('express-validator')



/**
 * @swagger
 * /user/create:
 *   post:
 *     summary: Register a new staff user
 *     description: Creates a new analytics dashboard user account
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [fn, sn, email, password]
 *             properties:
 *               fn:
 *                 type: string
 *               sn:
 *                 type: string
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Registration successful
 *       400:
 *         description: Validation error
 */
router.post('/create',
    doubleCsrfProtection,
    body('email').isEmail().normalizeEmail().withMessage('Invalid email'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('fn').trim().notEmpty().escape().withMessage('First name is required'),
    body('sn').trim().notEmpty().escape().withMessage('Surname is required'),
    async (req, res) => {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: errors.array()[0].msg })
        }

       
        const service = new userservice()
        const result = await service.create(req)
        res.json(result)
    }
)

/**
 * @swagger
 * /user/csrf-token:
 *   get:
 *     summary: Get CSRF token
 *     description: Returns a CSRF token for form submissions
 *     responses:
 *       200:
 *         description: CSRF token
 */
router.get('/csrf-token', (req, res) => {
    const token = generateCsrfToken(req, res)
    res.json({ csrfToken: token })
})


/**
 * @swagger
 * /user/retrieveByEmail:
 *   post:
 *     summary: Login user
 *     description: Authenticates user and returns JWT tokens via cookies
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, password]
 *             properties:
 *               email:
 *                 type: string
 *               password:
 *                 type: string
 *     responses:
 *       200:
 *         description: Login successful, redirects to dashboard
 *       401:
 *         description: Invalid credentials
 */
router.post('/retrieveByEmail',
    doubleCsrfProtection,
    body('email').isEmail().normalizeEmail().withMessage('Invalid email'),
    body('password').notEmpty().withMessage('Password is required'),
    async (req, res) => {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: errors.array()[0].msg })
        }

        try {
            const service = new userservice()
            const result = await service.retrieveByEmail(req)
            console.log("Result from retrieveByEmail route:", result)

            if (!result.success) {
                return res.status(401).json('failed to retrieve alumni by email')
            }

            res.cookie('access-token', result.data.accessToken, {
                httpOnly: true,
                secure: true,
                sameSite: true,
                maxAge: 24 * 60 * 60 * 1000
            })

            res.cookie('refresh-token', result.data.refreshToken, {
                httpOnly: true,
                secure: true,
                sameSite: true,
                maxAge: 7 * 24 * 60 * 60 * 1000
            })

            res.redirect('/ui/dashboard')
        } catch (error) {
            console.error('Error in /retrieveByEmail route:', error)
            res.status(500).json({ success: false, error: 'Internal server error' })
        }
    }
)


router.post('/refresh', async (req, res) => {
    const refreshToken = req.cookies?.['refresh-token']

    if (!refreshToken) {
        return res.status(401).json({ success: false, error: 'No refresh token' })
    }

    try {
        const decoded = await bearerToken.verifyRefreshToken(refreshToken)

        if (!decoded) {
            return res.status(401).json({ success: false, error: 'Invalid refresh token' })
        }

        const newTokens = await bearerToken.generateToken({
            userID: decoded.userID || decoded.id, 
            email: decoded.email,
            userType: decoded.userType
        })

        res.cookie('access-token', newTokens.accessToken, {
            httpOnly: true,
            secure: true,
            sameSite: true,
            maxAge: 15 * 60 * 1000
        })

        res.json({ success: true })
    } catch (error) {
        res.status(401).json({ success: false, error: 'Refresh token expired' })
    }
})


/**
 * @swagger
 * /user/reset-password:
 *   post:
 *     summary: Reset user password
 *     description: Updates password for the logged-in user after verifying current password
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [currentPassword, newPassword]
 *             properties:
 *               currentPassword:
 *                 type: string
 *               newPassword:
 *                 type: string
 *     responses:
 *       200:
 *         description: Password updated successfully
 *       400:
 *         description: Validation error
 *       401:
 *         description: Not authenticated
 */
router.post('/reset-password',
    jwtAuthMiddleware,
    doubleCsrfProtection,
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword')
        .isLength({ min: 8 }).withMessage('New password must be at least 8 characters')
        .matches(/[A-Z]/).withMessage('New password must contain an uppercase letter')
        .matches(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/).withMessage('New password must contain a special character'),
    async (req, res) => {
        const errors = validationResult(req)
        if (!errors.isEmpty()) {
            return res.status(400).json({ message: errors.array()[0].msg })
        }

        req.body.userID = req.user.userID
        const service = new userservice()
        const result = await service.resetPassword(req)
        console.log(result)
        res.json(result)
    }
)

module.exports = router