const express = require('express')
const router = express.Router()
const ExportService = require('../services/exportservice')


/**
 * @swagger
 * /export/csv/{type}:
 *   get:
 *     summary: Export chart data as CSV
 *     description: Downloads filtered data as a CSV file for the specified chart type
 *     parameters:
 *       - in: path
 *         name: type
 *         required: true
 *         schema:
 *           type: string
 *           enum: [alumni, certifications, sectors, career-pathways, top-employers, geographic]
 *         description: Type of data to export
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: CSV file download
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *       500:
 *         description: Export failed
 */
router.get('/csv/:type', async (req, res) => {
    try {
        const service = new ExportService()
        const { csv, filename } = await service.generateCSV(req.params.type, req.query)
        res.setHeader('Content-Type', 'text/csv')
        res.setHeader('Content-Disposition', `attachment; filename=${filename}`)
        res.send(csv)
    } catch (err) {
        res.status(500).json({ message: 'Export failed' })
    }
})

/**
 * @swagger
 * /export/pdf:
 *   get:
 *     summary: Generate PDF analytics report
 *     description: Downloads a formatted PDF report containing all analytics data with optional filters
 *     parameters:
 *       - in: query
 *         name: programme
 *         schema:
 *           type: string
 *         description: Filter by programme name
 *       - in: query
 *         name: year
 *         schema:
 *           type: string
 *         description: Filter by graduation year
 *     responses:
 *       200:
 *         description: PDF file download
 *         content:
 *           application/pdf:
 *             schema:
 *               type: string
 *               format: binary
 *       500:
 *         description: Export failed
 */
router.get('/pdf', async (req, res) => {
    try {
        const service = new ExportService()
        const doc = await service.generatePDF(req.query)
        res.setHeader('Content-Type', 'application/pdf')
        res.setHeader('Content-Disposition', 'attachment; filename=alumni-report.pdf')
        doc.pipe(res)
        doc.end()
    } catch (err) {
        res.status(500).json({ message: 'Export failed' })
    }
})

module.exports = router