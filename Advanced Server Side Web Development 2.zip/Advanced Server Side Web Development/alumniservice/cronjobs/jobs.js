const cron = require('node-cron')
const alumniservice = require('../services/alumniservice')
const bidsService = require('../services/bidservice')

const initCronJobs = () => {
    console.log('Initializing Cron Jobs for Alumni Service')
    cron.schedule('0 0 1 * *', async () => {
        const service = new alumniservice()
        await service.resetMonthlyAppearanceCount()
    })

    cron.schedule('0 18 * * *', async () => {
        const Alservice = new alumniservice()
        const BService = new bidsService()

        const Bresponse = await BService.selectBidWinner()
        if(!Bresponse.success){
            console.log(Bresponse.error || "Error when getting bid winner")
            return
        }

        const userID = Bresponse.data.bidderID

        const response = await Alservice.markWinner(userID)
        console.log(response)
    }) 

}

    
module.exports = initCronJobs