const axios = require('axios')
require('dotenv').config()

const authClient = axios.create({
    baseURL: process.env.BASE_URL,
    headers: { 'Content-Type': 'application/json' }
})

const permissionsByType = {
    'WEB': ['read:alumni', 'read:analytics','read:alumni_of_day'],
    'AR': ['read:alumni_of_day']
}

const validateApiKey = (requiredPermission) => async (req, res, next) => {
    console.log('=== Alumni middleware hit ===')
    console.log('Endpoint:', req.path)
    
    const apiKey = req.header('x-api-key')
    const referer = req.get('referer') || req.get('origin')
    const isLocalPage = referer && referer.includes(req.get('host'))

    

    if (isLocalPage) return next()

    if (!apiKey) {
        console.log('REJECTED: No API key')
        return res.status(401).json({ message: 'No API key provided' })
    }

    try {
        console.log('Calling auth service at:', process.env.BASE_URL + '/apikey/validate')
        const response = await authClient.post('/apikey/validate', { apiKey })
        console.log('Auth response:', response.data)

        if (!response.data.success) {
            console.log('REJECTED: Invalid key')
            return res.status(403).json({ message: 'Invalid or expired API key' })
        }

        const keyType = response.data.data.keyType
        console.log('Key type:', keyType, 'Required:', requiredPermission)

        const permissions = permissionsByType[keyType] || []

        if (requiredPermission && !permissions.includes(requiredPermission)) {
            console.log(' wrongg permissions')
            return res.status(403).json({ message: 'Insufficient permissions' })
        }

        console.log('allowed')
        req.apiKey = response.data.data
        next()
    } catch (err) {
        console.log(err.message)
        return res.status(403).json({ message: 'Key validation failed' })
    }
}

module.exports = { validateApiKey }