
const connection = require('./dbconfig')
connection.run('PRAGMA foreign_keys = ON');

// Helper to run a statement with params
function run(sql, params = []) {
    return new Promise((resolve, reject) => {
        connection.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve(this.lastID);
        });
    });
}

async function seed() {
    console.log('Seeding database...\n');
    await run(`ALTER TABLE employment_history ADD COLUMN sector TEXT`).catch(() => {});
await run(`ALTER TABLE alumni_profiles ADD COLUMN region TEXT`).catch(() => {});



    // ── Alumni Profiles (60 records) ──
    const alumni = [
        { userId: 1, fn: 'James', sn: 'Okonkwo', biography: 'Full stack developer with 5 years experience in fintech.', linkedinUrl: 'https://linkedin.com/in/jamesokonkwo' },
        { userId: 2, fn: 'Amara', sn: 'Patel', biography: 'Cloud architect specialising in AWS and Azure solutions.', linkedinUrl: 'https://linkedin.com/in/amarapatel' },
        { userId: 3, fn: 'David', sn: 'Chen', biography: 'Data scientist passionate about machine learning and NLP.', linkedinUrl: 'https://linkedin.com/in/davidchen' },
        { userId: 4, fn: 'Fatima', sn: 'Al-Hassan', biography: 'DevOps engineer focused on container orchestration.', linkedinUrl: 'https://linkedin.com/in/fatimaalhassan' },
        { userId: 5, fn: 'Oliver', sn: 'Williams', biography: 'Business analyst in healthcare technology sector.', linkedinUrl: 'https://linkedin.com/in/oliverwilliams' },
        { userId: 6, fn: 'Sophie', sn: 'Martin', biography: 'Frontend developer specialising in React and TypeScript.', linkedinUrl: 'https://linkedin.com/in/sophiemartin' },
        { userId: 7, fn: 'Mohammed', sn: 'Ibrahim', biography: 'Cybersecurity consultant for financial institutions.', linkedinUrl: 'https://linkedin.com/in/mohammedibrahim' },
        { userId: 8, fn: 'Emily', sn: 'Taylor', biography: 'Product manager at a leading edtech startup.', linkedinUrl: 'https://linkedin.com/in/emilytaylor' },
        { userId: 9, fn: 'Kwame', sn: 'Asante', biography: 'Backend engineer working with microservices architecture.', linkedinUrl: 'https://linkedin.com/in/kwameasante' },
        { userId: 10, fn: 'Hannah', sn: 'Brown', biography: 'UX researcher focused on accessibility and inclusive design.', linkedinUrl: 'https://linkedin.com/in/hannahbrown' },
        { userId: 11, fn: 'Raj', sn: 'Sharma', biography: 'Machine learning engineer at a computer vision startup.', linkedinUrl: 'https://linkedin.com/in/rajsharma' },
        { userId: 12, fn: 'Charlotte', sn: 'Davies', biography: 'IT consultant specialising in digital transformation.', linkedinUrl: 'https://linkedin.com/in/charlottedavies' },
        { userId: 13, fn: 'Yusuf', sn: 'Khan', biography: 'Mobile developer building cross-platform applications.', linkedinUrl: 'https://linkedin.com/in/yusufkhan' },
        { userId: 14, fn: 'Grace', sn: 'O\'Brien', biography: 'Data engineer building ETL pipelines for analytics.', linkedinUrl: 'https://linkedin.com/in/graceobrien' },
        { userId: 15, fn: 'Daniel', sn: 'Nowak', biography: 'Site reliability engineer ensuring 99.99% uptime.', linkedinUrl: 'https://linkedin.com/in/danielnowak' },
        { userId: 16, fn: 'Priya', sn: 'Nair', biography: 'Software engineer at a major banking institution.', linkedinUrl: 'https://linkedin.com/in/priyanair' },
        { userId: 17, fn: 'Thomas', sn: 'Hughes', biography: 'Blockchain developer working on DeFi protocols.', linkedinUrl: 'https://linkedin.com/in/thomashughes' },
        { userId: 18, fn: 'Aisha', sn: 'Mohammed', biography: 'QA automation engineer with Selenium and Cypress expertise.', linkedinUrl: 'https://linkedin.com/in/aishamohammed' },
        { userId: 19, fn: 'Lucas', sn: 'Garcia', biography: 'Systems architect designing scalable cloud infrastructure.', linkedinUrl: 'https://linkedin.com/in/lucasgarcia' },
        { userId: 20, fn: 'Zara', sn: 'Ahmed', biography: 'AI researcher focused on natural language understanding.', linkedinUrl: 'https://linkedin.com/in/zaraahmed' },
        { userId: 21, fn: 'Benjamin', sn: 'Clarke', biography: 'Project manager delivering agile software projects.', linkedinUrl: 'https://linkedin.com/in/benjaminclarke' },
        { userId: 22, fn: 'Mia', sn: 'Johnson', biography: 'Full stack developer working in the retail sector.', linkedinUrl: 'https://linkedin.com/in/miajohnson' },
        { userId: 23, fn: 'Hassan', sn: 'Ali', biography: 'Network engineer managing enterprise infrastructure.', linkedinUrl: 'https://linkedin.com/in/hassanali' },
        { userId: 24, fn: 'Isabella', sn: 'Romano', biography: 'Technical writer creating API documentation.', linkedinUrl: 'https://linkedin.com/in/isabellaromano' },
        { userId: 25, fn: 'Samuel', sn: 'Adeyemi', biography: 'Platform engineer building internal developer tools.', linkedinUrl: 'https://linkedin.com/in/samueladeyemi' },
        { userId: 26, fn: 'Emma', sn: 'Wilson', biography: 'Scrum master facilitating cross-functional teams.', linkedinUrl: 'https://linkedin.com/in/emmawilson' },
        { userId: 27, fn: 'Alex', sn: 'Petrov', biography: 'Game developer creating mobile gaming experiences.', linkedinUrl: 'https://linkedin.com/in/alexpetrov' },
        { userId: 28, fn: 'Naomi', sn: 'Scott', biography: 'Database administrator managing PostgreSQL clusters.', linkedinUrl: 'https://linkedin.com/in/naomiscott' },
        { userId: 29, fn: 'Ryan', sn: 'Murphy', biography: 'Solutions architect at a cloud services provider.', linkedinUrl: 'https://linkedin.com/in/ryanmurphy' },
        { userId: 30, fn: 'Leila', sn: 'Hussain', biography: 'Information security analyst protecting digital assets.', linkedinUrl: 'https://linkedin.com/in/leilahussain' },
        { userId: 31, fn: 'Jack', sn: 'Thompson', biography: 'Embedded systems engineer for IoT devices.', linkedinUrl: 'https://linkedin.com/in/jackthompson' },
        { userId: 32, fn: 'Sara', sn: 'Eriksson', biography: 'Marketing analyst using data to drive campaigns.', linkedinUrl: 'https://linkedin.com/in/saraeriksson' },
        { userId: 33, fn: 'Michael', sn: 'O\'Connor', biography: 'Software developer in the insurance industry.', linkedinUrl: 'https://linkedin.com/in/michaeloconnor' },
        { userId: 34, fn: 'Anya', sn: 'Volkov', biography: 'Cloud security engineer implementing zero trust.', linkedinUrl: 'https://linkedin.com/in/anyavolkov' },
        { userId: 35, fn: 'Chris', sn: 'Evans', biography: 'Technical lead managing a team of 8 developers.', linkedinUrl: 'https://linkedin.com/in/chrisevans' },
        { userId: 36, fn: 'Dina', sn: 'Mansour', biography: 'Data analyst creating dashboards for business intelligence.', linkedinUrl: 'https://linkedin.com/in/dinamansour' },
        { userId: 37, fn: 'Patrick', sn: 'Kelly', biography: 'DevOps engineer automating CI/CD pipelines.', linkedinUrl: 'https://linkedin.com/in/patrickkelly' },
        { userId: 38, fn: 'Nina', sn: 'Johansson', biography: 'UX designer crafting intuitive user interfaces.', linkedinUrl: 'https://linkedin.com/in/ninajohansson' },
        { userId: 39, fn: 'George', sn: 'Wright', biography: 'Backend developer building REST APIs with Node.js.', linkedinUrl: 'https://linkedin.com/in/georgewright' },
        { userId: 40, fn: 'Lena', sn: 'Fischer', biography: 'Machine learning engineer deploying models to production.', linkedinUrl: 'https://linkedin.com/in/lenafischer' },
        { userId: 41, fn: 'Adam', sn: 'Stewart', biography: 'IT support manager for a university campus.', linkedinUrl: 'https://linkedin.com/in/adamstewart' },
        { userId: 42, fn: 'Chloe', sn: 'Robinson', biography: 'Frontend engineer building component libraries.', linkedinUrl: 'https://linkedin.com/in/chloerobinson' },
        { userId: 43, fn: 'Ibrahim', sn: 'Diallo', biography: 'Cloud consultant helping SMEs migrate to AWS.', linkedinUrl: 'https://linkedin.com/in/ibrahimdiallo' },
        { userId: 44, fn: 'Jessica', sn: 'Lee', biography: 'Business intelligence analyst in retail analytics.', linkedinUrl: 'https://linkedin.com/in/jessicalee' },
        { userId: 45, fn: 'Nathan', sn: 'Hall', biography: 'Software engineer at a social media company.', linkedinUrl: 'https://linkedin.com/in/nathanhall' },
        { userId: 46, fn: 'Olivia', sn: 'King', biography: 'Systems administrator managing Linux servers.', linkedinUrl: 'https://linkedin.com/in/oliviaking' },
        { userId: 47, fn: 'Tariq', sn: 'Rashid', biography: 'Penetration tester identifying security vulnerabilities.', linkedinUrl: 'https://linkedin.com/in/tariqrashid' },
        { userId: 48, fn: 'Rebecca', sn: 'Moore', biography: 'Release manager coordinating software deployments.', linkedinUrl: 'https://linkedin.com/in/rebeccamoore' },
        { userId: 49, fn: 'Kevin', sn: 'Walsh', biography: 'Full stack developer in the travel tech industry.', linkedinUrl: 'https://linkedin.com/in/kevinwalsh' },
        { userId: 50, fn: 'Maya', sn: 'Singh', biography: 'Data scientist building recommendation systems.', linkedinUrl: 'https://linkedin.com/in/mayasingh' },
        { userId: 51, fn: 'Ethan', sn: 'Cox', biography: 'Software developer working on payment systems.', linkedinUrl: 'https://linkedin.com/in/ethancox' },
        { userId: 52, fn: 'Lily', sn: 'Bennett', biography: 'IT auditor ensuring compliance with regulations.', linkedinUrl: 'https://linkedin.com/in/lilybennett' },
        { userId: 53, fn: 'Oscar', sn: 'Reed', biography: 'API developer building integrations for SaaS platforms.', linkedinUrl: 'https://linkedin.com/in/oscarreed' },
        { userId: 54, fn: 'Freya', sn: 'Campbell', biography: 'Cloud engineer building serverless architectures.', linkedinUrl: 'https://linkedin.com/in/freyacampbell' },
        { userId: 55, fn: 'Liam', sn: 'Mitchell', biography: 'Junior developer learning full stack development.', linkedinUrl: 'https://linkedin.com/in/liammitchell' },
        { userId: 56, fn: 'Ava', sn: 'Cooper', biography: 'Technical project manager in financial services.', linkedinUrl: 'https://linkedin.com/in/avacooper' },
        { userId: 57, fn: 'Noah', sn: 'Phillips', biography: 'Infrastructure engineer managing Kubernetes clusters.', linkedinUrl: 'https://linkedin.com/in/noahphillips' },
        { userId: 58, fn: 'Isla', sn: 'Barnes', biography: 'Lecturer in computer science at a London university.', linkedinUrl: 'https://linkedin.com/in/islabarnes' },
        { userId: 59, fn: 'Jacob', sn: 'Price', biography: 'Startup founder building an AI-powered hiring tool.', linkedinUrl: 'https://linkedin.com/in/jacobprice' },
        { userId: 60, fn: 'Ruby', sn: 'Foster', biography: 'Healthcare data analyst improving patient outcomes.', linkedinUrl: 'https://linkedin.com/in/rubyfoster' },
    ];

    for (const a of alumni) {
        await run(
            `INSERT INTO alumni_profiles (userId, fn, sn, biography, linkedinUrl, appearanceCount, attendedEvent) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [a.userId, a.fn, a.sn, a.biography, a.linkedinUrl, Math.floor(Math.random() * 4), Math.round(Math.random())]
        );
    }
    console.log('✓ 60 alumni profiles inserted');

    // ── Degrees ──
    const programmes = [
        'BSc Computer Science', 'BSc Computer Science', 'BSc Computer Science',
        'BSc Business Management', 'BSc Business Management',
        'BEng Software Engineering', 'BEng Software Engineering',
        'BSc Data Science', 'BA Media & Communications'
    ];

    const grades = ['First Class', 'First Class', 'Upper Second', 'Upper Second', 'Upper Second', 'Lower Second'];
    const years = [2020, 2021, 2022, 2023, 2024];

    for (let i = 1; i <= 60; i++) {
        const prog = programmes[Math.floor(Math.random() * programmes.length)];
        const grade = grades[Math.floor(Math.random() * grades.length)];
        const startYear = years[Math.floor(Math.random() * years.length)] - 3;
        const endYear = startYear + 3;

        await run(
            `INSERT INTO degrees (alumnusId, degreeName, grade, universityUrl, startYear, completionDate) VALUES (?, ?, ?, ?, ?, ?)`,
            [i, prog, grade, 'https://www.westminster.ac.uk', `${startYear}-09-01`, `${endYear}-07-01`]
        );
    }
    console.log('✓ 60 degrees inserted');

    // ── Certifications ──
    const certs = [
        'Docker Certified Associate', 'AWS Solutions Architect', 'Kubernetes (CKA)',
        'Azure Administrator', 'Certified Scrum Master', 'MongoDB Developer',
        'Google Cloud Professional', 'Jenkins Engineer', 'Terraform Associate',
        'Python PCEP', 'CompTIA Security+', 'CISSP', 'PMP',
        'Tableau Desktop Specialist', 'Power BI Data Analyst'
    ];

    for (let i = 1; i <= 60; i++) {
        const numCerts = Math.floor(Math.random() * 5) + 1;
        const shuffled = [...certs].sort(() => Math.random() - 0.5);
        for (let j = 0; j < numCerts; j++) {
            const year = 2020 + Math.floor(Math.random() * 5);
            const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            await run(
                `INSERT INTO certifications (alumnusId, certName, courseUrl, completionDate) VALUES (?, ?, ?, ?)`,
                [i, shuffled[j], `https://example.com/cert/${shuffled[j].toLowerCase().replace(/\s/g, '-')}`, `${year}-${month}-15`]
            );
        }
    }
    console.log('✓ Certifications inserted');

    // ── Licences ──
    const licences = [
        'BCS Chartered IT Professional', 'CREST Registered Tester',
        'Cisco CCNA', 'Cisco CCNP', 'Microsoft Certified Trainer',
        'PRINCE2 Practitioner', 'ITIL Foundation'
    ];

    for (let i = 1; i <= 60; i++) {
        if (Math.random() > 0.5) {
            const lic = licences[Math.floor(Math.random() * licences.length)];
            const year = 2021 + Math.floor(Math.random() * 4);
            await run(
                `INSERT INTO licences (alumnusId, licenceName, awardingBodyUrl, completionDate) VALUES (?, ?, ?, ?)`,
                [i, lic, 'https://example.com/licence', `${year}-06-01`]
            );
        }
    }
    console.log('✓ Licences inserted');

    // ── Short Courses ──
    const shortCourses = [
        'Agile Fundamentals', 'React Advanced Patterns', 'Python for Data Analysis',
        'SQL Masterclass', 'Introduction to Machine Learning', 'Figma for Developers',
        'Microservices with Node.js', 'GraphQL Essentials', 'Leadership Skills',
        'Public Speaking for Tech', 'Negotiation Strategies', 'Financial Modelling'
    ];

    for (let i = 1; i <= 60; i++) {
        const numCourses = Math.floor(Math.random() * 3) + 1;
        const shuffled = [...shortCourses].sort(() => Math.random() - 0.5);
        for (let j = 0; j < numCourses; j++) {
            const year = 2020 + Math.floor(Math.random() * 5);
            const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            await run(
                `INSERT INTO short_courses (alumnusId, courseName, courseUrl, completionDate) VALUES (?, ?, ?, ?)`,
                [i, shuffled[j], `https://example.com/course/${shuffled[j].toLowerCase().replace(/\s/g, '-')}`, `${year}-${month}-10`]
            );
        }
    }
    console.log('✓ Short courses inserted');

    // ── Employment History ──
    const companies = [
        { name: 'Google', sector: 'Technology & IT' },
        { name: 'Amazon', sector: 'Technology & IT' },
        { name: 'Microsoft', sector: 'Technology & IT' },
        { name: 'Meta', sector: 'Technology & IT' },
        { name: 'IBM', sector: 'Technology & IT' },
        { name: 'Deloitte', sector: 'Consulting' },
        { name: 'Accenture', sector: 'Consulting' },
        { name: 'PwC', sector: 'Consulting' },
        { name: 'JPMorgan Chase', sector: 'Financial Services' },
        { name: 'Barclays', sector: 'Financial Services' },
        { name: 'Goldman Sachs', sector: 'Financial Services' },
        { name: 'HSBC', sector: 'Financial Services' },
        { name: 'NHS Digital', sector: 'Healthcare' },
        { name: 'Babylon Health', sector: 'Healthcare' },
        { name: 'BBC', sector: 'Media & Entertainment' },
        { name: 'Sky', sector: 'Media & Entertainment' },
        { name: 'Rolls-Royce', sector: 'Manufacturing' },
        { name: 'BAE Systems', sector: 'Manufacturing' },
        { name: 'University of London', sector: 'Education' },
        { name: 'Pearson', sector: 'Education' },
        { name: 'ASOS', sector: 'Retail & E-commerce' },
        { name: 'Deliveroo', sector: 'Retail & E-commerce' },
    ];

    const roles = [
        'Software Engineer', 'Software Engineer', 'Software Engineer',
        'Data Analyst', 'Data Analyst',
        'DevOps Engineer', 'DevOps Engineer',
        'Full Stack Developer', 'Full Stack Developer',
        'Cloud Engineer', 'Cloud Engineer',
        'Software Developer',
        'Business Analyst', 'Business Analyst',
        'Data Scientist',
        'IT Consultant', 'IT Consultant',
        'Product Manager',
        'QA Engineer',
        'Systems Administrator',
        'Security Analyst',
        'Technical Lead',
        'Scrum Master',
        'UX Designer',
        'Project Manager'
    ];

    const regions = [
        'London', 'London', 'London', 'London', 'London',
        'South East', 'South East',
        'North West', 'North West',
        'Midlands',
        'Scotland',
        'South West',
        'Europe', 'Europe',
        'North America',
        'Asia',
        'Middle East'
    ];

    for (let i = 1; i <= 60; i++) {
        // Current job
        const company = companies[Math.floor(Math.random() * companies.length)];
        const role = roles[Math.floor(Math.random() * roles.length)];
        const startYear = 2021 + Math.floor(Math.random() * 4);
        const startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');

        await run(
            `INSERT INTO employment_history (alumnusId, companyName, role, startDate, endDate) VALUES (?, ?, ?, ?, ?)`,
            [i, company.name, role, `${startYear}-${startMonth}-01`, null]
        );

        // Previous job (60% chance)
        if (Math.random() > 0.4) {
            const prevCompany = companies[Math.floor(Math.random() * companies.length)];
            const prevRole = roles[Math.floor(Math.random() * roles.length)];
            const prevStart = startYear - 2;
            await run(
                `INSERT INTO employment_history (alumnusId, companyName, role, startDate, endDate) VALUES (?, ?, ?, ?, ?)`,
                [i, prevCompany.name, prevRole, `${prevStart}-03-01`, `${startYear}-${startMonth}-01`]
            );
        }
    }
    console.log('✓ Employment history inserted');

    // ── Bids ──
    for (let i = 0; i < 120; i++) {
        const bidder = Math.floor(Math.random() * 60) + 1;
        const amount = Math.floor(Math.random() * 400) + 50;
        const month = String(Math.floor(Math.random() * 6) + 1).padStart(2, '0');
        const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
        const hour = String(Math.floor(Math.random() * 18) + 6).padStart(2, '0');

        await run(
            `INSERT INTO bids (bidAmount, bidderID, createdAt) VALUES (?, ?, ?)`,
            [amount, bidder, `2025-${month}-${day} ${hour}:00:00`]
        );
    }
    console.log('✓ 120 bids inserted');

    console.log('\n Seeding complete!');

    // Print summary
    connection.get('SELECT COUNT(*) as count FROM alumni_profiles', (e, r) => console.log(`   Alumni: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM degrees', (e, r) => console.log(`   Degrees: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM certifications', (e, r) => console.log(`   Certifications: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM licences', (e, r) => console.log(`   Licences: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM short_courses', (e, r) => console.log(`   Short Courses: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM employment_history', (e, r) => console.log(`   Employment Records: ${r.count}`));
    connection.get('SELECT COUNT(*) as count FROM bids', (e, r) => {
        console.log(`   Bids: ${r.count}`);
        connection.close();
    });
}

seed().catch(err => {
    console.error('Seeding failed:', err);
    connection.close();
});
