const userdao = require("../daos/userdao")
const bcryptUtility = require('../utils/bcryptutility')
const createResponse = require("../../shared-utils/reponse")
const bearerToken = require('../../shared-utils/bearerToken')

require('dotenv').config()

class userservice {
    constructor() {
        this.ud = new userdao()
    }

    async createUser(req) {
        const fn = req.body.fn
        const sn = req.body.sn
        const password = req.body.password
        const email = req.body.email

        console.log("CreateUser function called with request body inside service:", req.body) // Log the request body to see what is being received


        if (!fn || !sn || !password || !email) {

            return createResponse(false, null, null, "Please fill in all fields")
        }

        if (fn.trim() === '' || sn.trim() === '' || email.trim() === '' || password.trim() === '') {

            return createResponse(false, null, null, "Please fill in all fields")
        }

        if (password.length < 8) {
            return createResponse(false, null, null, "Password should be more then eight characters long")
        }

        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(password)) {
            return createResponse(false, null, null, "Password must contain at least one uppercase letter and one special character")
        }
        req.body.password = await bcryptUtility.encrypt(password)


        const result = await this.ud.createUser(req)

        console.log("Result from userdao.createUser:", result) // Log the result from the DAO to see what is being returned

        return result
    }

    async retrieveByEmail(req) {

        const password = req.body.password
        const email = req.body.email
        if (!password || !email) {
            return createResponse(false, null, null, "Please fill in all fields")
        }

        if (email.trim() === '' || password.trim() === '') {
            return createResponse(false, null, null, "Please fill in all fields")
        }

        if (password.length < 8) {
            return createResponse(false, null, null, "Invalid Password")
        }


        const result = await this.ud.retrieveByEmail(email)
        console.log("Result from userdao.retrieveByEmail:", result) // Log the result from the DAO 

        if (!result.success) {
            return createResponse(false, null, null, "Incorrect Details")
        }

        const isPWMatch = await bcryptUtility.verify(password, result.data.password)

        console.log('Password match:', isPWMatch)

        if (!isPWMatch) {
            return createResponse(false, null, null, "Incorrect Details")
        }


        const user = {
            id: result.data.id,
            email: result.data.email,
            userType: result.data.userType
        }
        return createResponse(true, user)

    }

    async retrieveAll(req) {


        const result = await this.ud.retrieveAll(req)

        return result
    }

    async updateUser(req) {

    }

    async updatePassword(req) {
        const newPassword = req.body.newPassword
        const currentPassword = req.body.currentPassword
        const userId = req.body.userID
        console.log("REQ:",req.body)

        const passwordRegex = /^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/
        if (!passwordRegex.test(newPassword)) {
            return createResponse(false, null, null, "Password must contain at least one uppercase letter and one special character")
        }


        const user = await this.ud.findById(userId)

        console.log(user)

        if (!user || !user.data) {
            return createResponse(false, null, null, "User not found")
        }

        const isMatch = await bcryptUtility.verify(currentPassword, user.data.password)

        if (!isMatch) {
            return createResponse(false, null, null, "Current password is incorrect")
        }

       
        req.body.newPassword = await bcryptUtility.encrypt(newPassword)

        return await this.ud.updatePassword(req)
    }



    async deleteUserWithID(req) {

    }
}

module.exports = userservice