const userservice = require("../services/userservice")
const hashService = require("../../shared-utils/hashService") 
const createResponse = require("../../shared-utils/reponse")
const AUTH_SERVER_ID = process.env.AUTH_SERVER_ID

const express = require("express")

const router = express.Router()


/**
 * @swagger
 * /user/create:
 *   post:
 *     summary: Register a new user
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - fn
 *               - sn
 *               - email
 *               - password
 *               - userType
 *             properties:
 *               fn:
 *                 type: string
 *                 example: Bobinda
 *               sn:
 *                 type: string
 *                 example: timothy
 *               email:
 *                 type: string
 *                 example: you@westminster.ac.uk
 *               password:
 *                 type: string
 *                 example: Abcd1234!
 *               userType:
 *                 type: string
 *                 example: Alumni
 *     responses:
 *       200:
 *         description: User created successfully
 *       400:
 *         description: Validation error
 */
router.post("/create", async (req , res) => {

    this.userservice = new userservice()
    const result = await this.userservice.createUser(req)
    const hashedServiceID = await hashService(AUTH_SERVER_ID)
    console.log("Create user result last log:", result) // Log the result to see what is being returned from the service
    
    if(!result.error){
        result.error = null
    }
    
    console.log("Create user result before response:", result.data) // Log the result again before sending the response to see if it has been modified
    res.json(createResponse(result.success,result.data, hashedServiceID,result.error))
    


})

/**
 * @swagger
 * /user/retrieveAll:
 *   get:
 *     summary: Retrieve all users
 *     tags: [Users]
 *     security:
 *       - ApiKeyAuth: []
 *     responses:
 *       200:
 *         description: List of all users
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: integer
 *                         example: 1
 *                       fn:
 *                         type: string
 *                         example: James
 *                       sn:
 *                         type: string
 *                         example: Okonkwo
 *                       email:
 *                         type: string
 *                         example: you@westminster.ac.uk
 *                       userType:
 *                         type: string
 *                         example: Alumni
 *                 serviceID:
 *                   type: string
 *                   example: cc9dcdf3c4eb...
 *                 error:
 *                   type: string
 *                   nullable: true
 *       403:
 *         description: Invalid API key
 */
router.get("/retrieveAll", async (req , res) => {
    this.userservice = new userservice()
    const result = await this.userservice.retrieveAll(req)
    const hashedServiceID = await hashService(AUTH_SERVER_ID)

    if(!result.error){
        result.error = null
    }

    res.json(createResponse(result.success,result.data, hashedServiceID,result.error))
    
    
})

/**
 * @swagger
 * /user/retrieveByEmail:
 *   post:
 *     summary: Login - retrieve user by email and verify password
 *     tags: [Users]
 *     security:
 *       - ApiKeyAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - password
 *             properties:
 *               email:
 *                 type: string
 *                 example: you@westminster.ac.uk
 *               password:
 *                 type: string
 *                 example: Abcd1234!
 *     responses:
 *       200:
 *         description: User retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: integer
 *                       example: 1
 *                     email:
 *                       type: string
 *                       example: you@westminster.ac.uk
 *                     userType:
 *                       type: string
 *                       example: Alumni
 *                 serviceID:
 *                   type: string
 *                   example: cc9dcdf3c4eb...
 *                 error:
 *                   type: string
 *                   nullable: true
 *       401:
 *         description: Invalid credentials
 *       429:
 *         description: Too many login attempts
 */
router.post("/retrieveByEmail", async (req , res) => {

    this.userservice = new userservice()
   
    const result = await this.userservice.retrieveByEmail(req)
    const hashedServiceID = await hashService(AUTH_SERVER_ID)
    if(!result.error){
        result.error = null
    }
    console.log("Retrieve by email result before response:", result.data) //
    res.json(createResponse(result.success,result.data, hashedServiceID,result.error))
    
})
router.delete("/deleteUserWithID", async (req , res) => {

    
})

router.post("/reset-password", async (req , res) => {  
    
    this.userservice = new userservice()

    const result = await this.userservice.updatePassword(req)
    const hashedServiceID = await hashService(AUTH_SERVER_ID)
    
    res.json(createResponse(result.success,result.data, hashedServiceID,result.error || null))


})


router.post("/update", async (req , res) => {  
    
})

module.exports = router