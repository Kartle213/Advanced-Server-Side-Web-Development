const apikeyserice = require("../services/apikeyservice")
const createResponse = require('../../shared-utils/reponse')
const hashService = require('../../shared-utils/hashService')
const AUTH_SERVER_ID = process.env.AUTH_SERVER_ID

const express = require("express")

const router = express.Router()

router.get("/create", async (req , res) => {

    this.apikeyserice = new apikeyserice()
    const result = await this.apikeyserice.create(req)
    const hashedServicedID = await hashService(AUTH_SERVER_ID)

    if (!result.error){
        result.error = null
    }
    res.json(createResponse(result.success,result.data,hashedServicedID,result.error))

})

router.get("/getAll", async (req , res) => {
    
    this.apikeyserice = new apikeyserice()
    const result = await this.apikeyserice.getAllKeys(req)
    const hashedServicedID = await hashService(AUTH_SERVER_ID)

    if (!result.error){
        result.error = null
    }
    res.json(createResponse(result.success,result.data,hashedServicedID,result.error))
  

})

router.post('/validate', async (req, res) => {
    try {
        const service = new apikeyserice()
        const result = await service.getByKey(req.body.apiKey)
        res.json(result)
    } catch (err) {
        console.error('Validate error:', err)
        res.status(500).json({ success: false, message: 'Validation failed' })
    }
})

module.exports = router